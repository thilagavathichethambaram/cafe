import React, { useEffect, useState } from "react";
import { Container, Grid } from "@mui/material";
import CustomDropdownMui from "../../../Components/CustomDropDown/CustomDropdown";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import { Form, Formik } from "formik";
import CustomRadioButton from "../../../Components/CustomRadioBtn/CustomRadioButton";
import CusTable from '../../../Components/CustomTable/CusTable';
import * as MASTER from "../../../Components/CustomTable/Tableentries";
import actions from "../../../ReduxStore/actions/index";
import { useDispatch, useSelector } from "react-redux";

const RoleMaster = () => {
  
  const dispatch = useDispatch();
  const [changebtn, setchangebtn] = useState(true);
  

  const handleSubmit = (values, { setSubmitting, resetForm }) => {
   // if (changebtn) {
      const data1 = {
        data: { ...values },
        method: "post",
        apiName: "createrole",
      };
      dispatch(actions.ROLLMASTERCREATE(data1));
      const data = { data: {}, method: "get", apiName: "role" };
      dispatch(actions.ROLEMASTERGETALL(data));
    //}
  };

  // UseSelector to get data from the Redux store
  const RoleMasterGetAll = useSelector((state) => state.RoleMasterGetAll);

  useEffect(() => {
    const data1 = { data: {}, method: "get", apiName: "role" };
    dispatch(actions.ROLEMASTERGETALL(data1));
  }, [dispatch]);
  
  const[rowTableData, setRowTableData] = useState([]);

  useEffect(() => {
    
  
      const tempArr1 = [];
      RoleMasterGetAll?.data?.map((data, index) => {
      return tempArr1.push({
        Sno: index + 1,
        role_id: data.role_id,
        role_name: data.role_name,
        active_status:data.active_status,
        
      });
    });
    
    setRowTableData(tempArr1);
    
  }, [RoleMasterGetAll]);
  console.log(rowTableData, "rowTabledata////")

  const status = [
    { label: "Active", value: "All" },
    { label: "Inactive", value: "Branch" },
  ];
/////////////////
const { UserRoleDropDown } = useSelector(
  (state) => state?.UserRoleDropDown
);
// console.log(BranchDropDown, "BranchDropDownllllll");

useEffect(() => {
  const data = { data: {}, method: "get", apiName: "roleDropDown" };
  dispatch(actions.USERROLEDROPDOWN(data));
}, [dispatch]);

const [UserRoleDrop, setUserRoleDrop] = useState([]);
useEffect(() => {
  const tempArr = [];
 UserRoleDropDown?.data?.map((values, index) =>
    tempArr.push({
      value: values?.userrole_id,
      label: values?.role_name,
    })
  );
  setUserRoleDrop(tempArr);
}, [UserRoleDropDown]);
  return (
    <div style={{ height: "100%", width: "100%" }}>
      <Grid container md={12} style={{ height: "100%" }}>
        {/* input field */}
        <Grid item md={12} sx={{ marginTop: "20px" }}>
          <Formik
            initialValues={{
              role_id: "",
            role_name: "",
            active_status: "",
        
              
            }}
            style={{ height: "100%" }}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting, resetForm, setFieldValue }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "0px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  {/* heading Row */}
                  <Grid container sx={{ height: "100%" }}>
                    {/* First Row */}
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="User ID"
                        name="role_id"
                        inputType={"text"}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDropdownMui
                        label="User Role"
                        name="role_name"
                        custPlaceholder="Select Branch"
                        setFieldValue={setFieldValue}
                        options={UserRoleDrop}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomRadioButton
                        label="Status"
                        name="active_status"
                        options={status}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    ></Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    ></Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        alignItems: "end",
                        marginTop: "15px",
                      }}
                    >
                      <button
                        type="submit"
                        onClick={isSubmitting}
                       //onClick={}
                      
                        className="expense-submit-btn"
                      >
                        Submit
                      </button>
                      <button
                        type="button"
                        disabled={isSubmitting}
                        onClick={() => {
                          resetForm();
                          setchangebtn(true);
                        }}
                        className="expense-cancel-btn"
                        style={{ border: "1px solid var(--primary-color)" }}
                      >
                        Cancel
                      </button>
                    </Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.RoleMasterTableHeaders}
                  Tabledata={rowTableData}
                  TableTittle="Overview"
                  showSearch={true}
                />
              </Grid>
            </Grid>
          </Container>
        </Grid>
      </Grid>
    </div>
  );
};

export default RoleMaster;
