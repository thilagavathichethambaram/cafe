import { Email, Password } from "@mui/icons-material";
import { Container, Grid } from "@mui/material";
import { Form, Formik } from "formik";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDropdownMui from "../../../Components/CustomDropDown/CustomDropdown";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import CustomRadioButton from "../../../Components/CustomRadioBtn/CustomRadioButton";
import CusTable from "../../../Components/CustomTable/CusTable";
import * as MASTER from "../../../Components/CustomTable/Tableentries";
import NestedModal from "../../../Components/EyeButton/EyeButton3";
import actions from "../../../ReduxStore/actions";
const UserMaster = () => {
  const dispatch = useDispatch();
  const { UserDropDown } = useSelector((state) => state?.UserDropDown);
  // console.log(BranchDropDown, "BranchDropDownllllll");

  useEffect(() => {
    const data = { data: {}, method: "get", apiName: "roleDropDown" };
    dispatch(actions.USERDROPDOWN(data));
  }, [dispatch]);

  const [UserDrop, setBranchDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.userrole_id,
        label: values?.role_name,
      })
    );
    setBranchDrop(tempArr);
  }, [UserDropDown]);

  const useraccess = [
    { label: "All", value: 0 },
    { label: "Branch", value: 1 },
  ];
  const status = [
    { label: "Active", value: "All" },
    { label: "InActive", value: "Branch" },
  ];
  function validateEmail(value) {
    let error = "";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const allowedDomains = ["gmail.com", "yahoo.com", "outlook.com"];

    if (!value) {
      error = "Email is required";
    } else if (!emailRegex.test(value)) {
      error = "Invalid email address";
    } else {
      const domain = value.split("@")[1];
      if (!allowedDomains.includes(domain)) {
        error = "Email domain must be @gmail.com, @yahoo.com, or @outlook.com";
      }
    }
    return error;
  }
  const formikRef = useRef();

  const [companyModel, setCompanyModel] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState(null);
  const [changebtn, setchangebtn] = useState(true);
  const { UserMasterCreate } = useSelector((state) => state?.UserMasterCreate);
  const { UserGetById } = useSelector((state) => state?.UserGetById);
  const { UserUpdate } = useSelector((state) => state?.UserUpdate);
  const { UserDelete } = useSelector((state) => state?.UserDelete);
  const { UserGetAll } = useSelector((state) => state?.UserGetAll);
  const handleSubmit = (values, { setSubmitting, resetForm }) => {
    // alert("hhhh");
    // console.log("values", values);
    if (changebtn) {
      alert("hhhh");
      const data1 = {
        data: { ...values },
        method: "post",
        apiName: "User",
      };
      dispatch(actions.USERMASTERCREATE(data1));
      const data = { data: {}, method: "get", apiName: "User" };
      dispatch(actions.USERGETALL(data));
    } else {
      const data2 = {
        data: { ...values },
        method: "put",
        apiName: `User/${UserGetById?.data?.user_id}`,
      };
      dispatch(actions.USERUPDATE(data2));
      setchangebtn(true);
    }
    resetForm();
    setSubmitting(false);
  };
  const onViewClick = (id) => {
    const data = {
      data: {},
      method: "get",
      apiName: `User/${id?.user_id}`,
    };
    dispatch(actions.USERGetById(data)).then(() => {
      const UserData = UserGetById.data;
      if (formikRef.current && UserData) {
        Object.keys(UserData).forEach((key) => {
          formikRef.current.setFieldValue(key, UserData[key]);
        });
      }
      setchangebtn(false);
    });
  };

  const handleDelete = (id) => {
    console.log("user_id", id);
    const data = {
      data: {},
      method: "DELETE",
      apiName: `User/${id?.user_id}`,
    };
    dispatch(actions.USERDELETE(data));
  };

  useEffect(() => {
    const data1 = { data: {}, method: "get", apiName: "User" };
    dispatch(actions.USERGETALL(data1));
  }, [dispatch, UserMasterCreate, UserUpdate, UserDelete]);

  const [rowTableData, setRowTableData] = useState([
    {
      Sno: "1",
      Branch: "",
      Id: "--",
      Name: "--",
      Email: "--",
      User_Role: "--",
      User_Access: "--",
    },
  ]);

  useEffect(() => {
    const tempArr1 = [];
    UserGetAll?.data?.map((data, index) => {
      return tempArr1.push({
        Sno: index + 1,
        branch: data.branch_location,
        user_id: data.user_id,
        employee_name: data.employee_name,
        role_name: data.role_name,
        employee_email: data.employee_email,
        user_access: data.user_access,
        active_status: data.active_status,
      });
    });
    setRowTableData(tempArr1);
  }, [UserGetAll]);

  const handleViewClick = (id) => {
    setSelectedCompanyId(id);
    setCompanyModel(true);
  };
  return (
    <div style={{ height: "100%", width: "100%" }}>
      <Grid
        container
        md={12}
        style={{
          height: "100%",
        }}
      >
        {/* input field */}
        <Grid item md={12} sx={{ marginTop: "20px" }}>
          <Formik
            initialValues={{
              branch_id: 4,
              employee_id: 3,
              employee_name: "",
              password: "",
              userrole_id: "",
              user_access: "",
              active_status: "",
            }}
            style={{ height: "100%" }}
            onSubmit={handleSubmit}
            innerRef={formikRef}
          >
            {({ isSubmitting, resetForm, setFieldValue }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "0px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  {/* heading Row */}
                  <Grid container sx={{ height: "100%" }}>
                    {/* First Row */}
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDropdownMui
                        label="Branch"
                        name="branch_id"
                        custPlaceholder="Select Branch"
                        setFieldValue={setFieldValue}
                        options={[
                          // {value:"0",label:""},
                          { value: "1", label: "Mohan&Co" },
                          { value: "2", label: "Empty Cafe" },
                          { value: "3", label: "Tea Boy" },
                        ]}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomDropdownMui
                        label="Employee Id"
                        custPlaceholder=""
                        name="employee_id"
                        setFieldValue={setFieldValue}
                        options={[
                          // {value:"0",label:""},
                          { value: "1", label: "Mohan&Co" },
                          { value: "2", label: "Empty Cafe" },
                          { value: "3", label: "Tea Boy" },
                        ]}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Employee Name"
                        name="employee_name"
                        inputType={"text"}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Email"
                        name="employee_email"
                        inputType={Email}
                        validate={validateEmail}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Password"
                        name="password"
                        inputType={Password}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomDropdownMui
                        label="UserRole"
                        name="userrole_id"
                        custPlaceholder="Select Branch"
                        setFieldValue={setFieldValue}
                        options={UserDrop}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomRadioButton
                        label="User Access"
                        name="user_access"
                        options={useraccess}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",

                        marginTop: "5px",
                      }}
                    >
                      <CustomRadioButton
                        label="Status"
                        name="active_status"
                        options={status}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        alignItems: "end",
                        marginTop: "15px",
                      }}
                    >
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="expense-submit-btn"
                      >
                        {changebtn ? "Submit" : "Update"}
                      </button>
                      <button
                        type="button"
                        disabled={isSubmitting}
                        onClick={() => {
                          resetForm();
                          setchangebtn(true);
                        }}
                        className="expense-cancel-btn"
                        style={{ border: "1px solid var(--primary-color)" }}
                      >
                        Cancel
                      </button>
                    </Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12} sx={{}}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
              //   boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.UserMasterTableHeaders}
                  Tabledata={rowTableData}
                  TableTittle="Overview"
                  handleDelete={handleDelete}
                  setmyDefaultFieldValues={onViewClick}
                  showAction={true}
                  showSearch={true}
                  onViewClick={onViewClick}
                  handleViewClick={handleViewClick}
                />
              </Grid>
              {companyModel && (
                <NestedModal
                  open={companyModel}
                  onClose={() => setCompanyModel(false)}
                  id={selectedCompanyId}
                />
              )}
            </Grid>
          </Container>
        </Grid>
      </Grid>
      {/* </Grid> */}
    </div>
  );
};

export default UserMaster;