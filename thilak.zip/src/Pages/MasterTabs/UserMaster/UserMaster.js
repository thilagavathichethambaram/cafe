import { Password } from "@mui/icons-material";
import { Container, Grid } from "@mui/material";
import { Form, Formik } from "formik";
import React, { useEffect, useState,useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDropdownMui from "../../../Components/CustomDropDown/CustomDropdown";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import CustomInputDisable from "../../../Components/CustomInputDisable/CustomInputDisable";
import CustomRadioButton from "../../../Components/CustomRadioBtn/CustomRadioButton";
// import CustomSearchInput from "../../../Components/CustomSearchInput/CustomSearchInput";
import CusTable from "../../../Components/CustomTable/CusTable";
import * as MASTER from "../../../Components/CustomTable/Tableentries";
import actions from "../../../ReduxStore/actions/index";
import NestedModal from "../../../Components/EyeButton/EyeButton3";
import axios from "axios";
const UserMaster = () => {
  const dispatch = useDispatch();
  const formikRef = useRef();
  const [changebtn, setchangebtn] = useState(true);
  const [companyModel, setCompanyModel] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState(null);
  ////////////////////BranchDropDown
  const { UserMasterBranchDropDown } = useSelector(
    (state) => state?.UserMasterBranchDropDown
  );
  // console.log(BranchDropDown, "BranchDropDownllllll");

  useEffect(() => {
    const data = { data: {}, method: "get", apiName: "branchDropDown" };
    dispatch(actions.USERMASTERBRANCHDROPDOWN(data));
  }, [dispatch]);

  const [branchDrop, setBranchDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserMasterBranchDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.branch_id,
        label: values?.branch_location,
      })
    );
    setBranchDrop(tempArr);
  }, [UserMasterBranchDropDown]);

  const [branchVal, setBranchVal] = useState(null);
  console.log("selectedValue", branchVal);

  const handleDrop = (name, selectedValue) => {
    setBranchVal(selectedValue);
  };
  //////////////////delete
  const { UserDelete } = useSelector((state) => state.UserDelete);

  const handleDelete = (id) => {
    const data = {
      data: {},
      method: "DELETE",
      apiName: `User/${id?.user_id}`,
    };
    dispatch(actions.USERDELETE(data));
    if (UserDelete?.data) {
      console.log("Successfully Deleted!");
    } else {
      console.log("failed");
    }
  };
  /////////////////////////////empBranchDropDown
  const { UserEmployeeDropDown } = useSelector(
    (state) => state?.UserEmployeeDropDown
  );
  console.log(UserEmployeeDropDown, "BranchDropDownllllll");


  const [EmployeeDrop, setEmployeeDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserEmployeeDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.employee_id,
        label: values?.employee_unique_id,
      })
    );
    setEmployeeDrop(tempArr);
  }, [UserEmployeeDropDown]);
 

  const [employeeValue, setEmployeeValue] = useState("");
  useEffect(() => {
    // if(employeeValue){
    const data = {
      data: {},
      method: "get",
      apiName: "employeeDetailsForUserMaster",
    };
    // dispatch(actions.USERDROPDOWN(data));
    // }
  }, [employeeValue, dispatch]);

  const employeeDropDown = (selectedValue) => {
    alert("yyy");
    console.log("employeeDropDown", selectedValue);
    setEmployeeValue(selectedValue);
  };

 
  const [employeeVal, setemployeeVal] = useState(null);
  console.log("selectedValue", employeeVal);

  ////////////////////
  const [employeeName, setEmployeeName] = useState(" ");
  const [empId, setEmpId] = useState("");
  console.log("employeeName",employeeName,empId);
  const [employeeEmail, setEmployeeEmail] = useState(" ");
  const [button1Disabled, setButton1Disabled] = useState(false);
  const [button2Disabled, setButton2Disabled] = useState(false);

  

  const selectEmployeeIdfn = async (name, id, email) => {
    setEmpId(id)
  };
  ////////////////
  const handleViewClick = (id) => {
    setSelectedUserId(id);
    setCompanyModel(true);
  };
  ///////////
  useEffect(()=>{
    if(empId){
      const getemp_name = UserEmployeeDropDown?.data?.filter(
        (data) => data.employee_id == empId
      );
      setEmployeeName(getemp_name[0].employee_name);
      setEmployeeEmail(getemp_name[0].employee_email);
    }
  },[empId])
  

  ////////////
  const useraccess = [
    { label: "All", value: "All" },
    { label: "Branch", value: "Branch" },
  ];
  const status = [
    { label: "Active", value: "1" },
    { label: "Inactive", value: "0" },
  ];


  useEffect(() => {
    if (branchVal) {
      const data3 = {
        data: { branch_id: branchVal },
        method: "post",
        apiName: "getEmployeesByBranchId",
      };
      dispatch(actions.USEREMPLOYEEDROPDOWN(data3));
    }
  }, [branchVal, dispatch]);

  ////////////////
  const [BranchDropDownIdSelect, setBranchDropDownIdSelect] = useState("");
  const selectBranchIdfn = (name, id) => {
    console.log(name, "selectBranchIdfn");
    console.log(id, "selectBranchIdfn");
    setBranchDropDownIdSelect(id);

    const data3 = {
      data: { branch_id: branchVal },
      method: "post",
      apiName: "getEmployeesByBranchId",
    };
    // dispatch(actions.USEREMPLOYEEDROPDOWN(data3));
  };

  const [BranchEmployeeDrop, setBranchEmployeeDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserEmployeeDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.employee_id,
        label: values?.employee_unique_id,
      })
    );
    setBranchEmployeeDrop(tempArr);
  }, [UserEmployeeDropDown]);
// ..............................................................
const { UserRoleDropDown } = useSelector(
  (state) => state?.UserRoleDropDown
);
// console.log(BranchDropDown, "BranchDropDownllllll");

useEffect(() => {
  const data = { data: {}, method: "get", apiName: "roleDropDown" };
  
  dispatch(actions.USERROLEDROPDOWN(data));
}, [dispatch]);

const [UserRoleDrop, setUserRoleDrop] = useState([]);

useEffect(() => {
  const tempArr = [];
 UserRoleDropDown?.data?.map((values, index) =>
  
  tempArr.push({
      value: values?.role_id,
      label: values?.role_name,
      
    }
  )
   
    );
    
  setUserRoleDrop(tempArr);
}, [UserRoleDropDown]
);

 ////////////Create
//  const handleSubmit = (values, { setSubmitting, resetForm }) => {
//   // Handle form submission
//   console.log(values);
//   if (changebtn) {
//     const data1 = {
//       data: { ...values },
//       method: "post",
//       apiName: "User",
//     };

//     dispatch(actions.USERMASTERCREATE(data1));

//     const data = { data: {}, method: "get", apiName: "User" };
//     dispatch(actions.USERGETALL(data));
//   }

//   /////////////////////
//   else {
//     const data2 = {
//       data: { ...values },
//       method: "put",
//       apiName: `User/${apiUpdateId}`,
//     };
//     dispatch(actions.USERUPDATE(data2));
//     setchangebtn(true);
//   }

//   resetForm();
//   setSubmitting(false);
// };

//------------------------------------------------------------------------------------------------------------------------

const handleSubmit = (values, { setSubmitting, resetForm }) => {
  if (changebtn) {
    const data1 = {
      data: { ...values },
      method: "post",
      apiName: "User",
    };
    dispatch(actions.USERMASTERCREATE(data1));
    const data = { data: {}, method: "get", apiName: "User" };
    dispatch(actions.USERGETALL(data));
  } else {
    const data2 = {
      data: { ...values },
      method: "put",
      apiName: `User/${apiUpdateId}`,
    };
    dispatch(actions.USERUPDATE(data2));
    setchangebtn(true);
  }
  resetForm();
  setSubmitting(false);
};
//---------------------------------------------------------------------------------------------------------------------
/////////getall
const { UserGetAll } = useSelector((state) => state?.UserGetAll);
  useEffect(() => {
    const data1 = { data: {}, method: "get", apiName: "User" };
    dispatch(actions.USERGETALL(data1));
  }, [dispatch]);

  const [rowTableData, setRowTableData] = useState([]);

  useEffect(() => {
     
      const tempArr1 =[];
       UserGetAll?.data?.map((data, index) => {
        return tempArr1.push({
        Sno: index + 1,
        user_id:data.user_id,
        branch_location: data.branch_location,
        employee_id:data.employee_id,
        employee_name:data.employee_name,
        employee_email:data.employee_email,
        role_name:data.role_name,
        active_status: data.active_status,
      //   user_id:data.user_id,
      //   password:data.password,
      //   user_access:data.user_access,
        
       
      //   branch_location:data.branch_location,
       
      
      
      //  role_id: data.role_id,
       
        
      });
      });

      setRowTableData(tempArr1);
    
  }, [UserGetAll]);
  // ...............................getbyid
  const { UserGetById } = useSelector((state) => state?.UserGetById);
  // const onViewClick = (id) => {
  //   const data = {
  //     data: {},
  //     method: "get",
  //     apiName: `User/${id?.user_id}`,
  //   };
  //   dispatch(actions.USERGetById(data)).then(() => {
  //     const UserData = UserGetById.data;
  //     if (formikRef.current && UserData) {
  //       Object.keys(UserData).forEach((key) => {
  //         formikRef.current.setFieldValue(key, UserData[key]);
  //       });
  //     }
  //     setchangebtn(false);
  //   });
  // };
  //------------------------------------------------------------------------------------------
 const[apiUpdateId,setapiUpdateId]=useState(null);
  const setmyDefaultFieldValues = async (id) => {
      console.log(id, "edit id");
    
      try {
          const response = await axios.get(
             `http://122.165.52.124:5500/api/v1/User/${id?.user_id}`
          );
          const UserData = await response.data;
          console.log(UserData, "UserData");
    
          const { setFieldValue } = formikRef.current;
          if (setFieldValue) {
            //setFieldValue("branch_id", branchData.data.branch_id);
            setFieldValue("user_id", UserData.data.user_id);
              setFieldValue("password", UserData.data.password);
              
              setFieldValue("active_status", UserData.data.active_status);
              setFieldValue("branch_id", UserData.data.branch_id);
              setFieldValue("branch_location", UserData.data.branch_location);
              setFieldValue("employee_id", UserData.data.employee_id);
              setFieldValue("employee_unique_id", UserData.data.employee_unique_id);
              setFieldValue("employee_email", UserData.data.employee_email);
              setFieldValue("employee_name", UserData.data.employee_name);
              setFieldValue("designation_id", UserData.data.designation_id);
              
              // Add more field assignments as needed
          }
    
          setchangebtn(false);
      } catch (error) {
          console.error("Error fetching branch data:", error);
          // Handle error
      }
       setapiUpdateId(id?.user_id)
    };
  return (
    <div style={{ height: "100%", width: "100%" }}>
      <Grid
        container
        md={12}
        style={{
          height: "100%",
        }}
      >
        {/* input field */}
        <Grid item md={12} sx={{ marginTop: "20px" }}>
          <Formik
            initialValues={{
              branch_id: "",
              employee_id: " ",
             password: "",
             role_id: "role_id",
              // user_access: "",
              active_status: "",
            }}
            style={{ height: "100%" }}
             onSubmit={handleSubmit}
             innerRef={formikRef}
          >
            {({ isSubmitting, resetForm, setFieldValue }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "0px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  {/* heading Row */}
                  <Grid container sx={{ height: "100%" }}>
                    {/* First Row */}
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDropdownMui
                        label="Branch"
                        name="branch_id"
                        custPlaceholder="Select Branch"
                        setFieldValue={setFieldValue}
                        options={branchDrop}
                        selectEmployeeIdfn={handleDrop}
                        // selectBranchIdfn={selectBranchIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      {/* <CustomSearchInput
                        label="Employee Id"
                        name="employee_id"
                        custPlaceholder="Search Employee Id"
                        setFieldValue={setFieldValue}
                        selectEmployeeIdfn={selectEmployeeIdfn}
                        options={timeSheetDrop}
                        setEmployeeName={setEmployeeName}
                        
                      /> */}
                      <CustomDropdownMui
                        label="Employee Id"
                        name="employee_id"
                        custPlaceholder=""
                        setFieldValue={setFieldValue}
                        // selectEmployeeIdfn={selectEmployeeIdfn}

                        options={EmployeeDrop}
                        // selectEmployeeIdfn={employeeDropDown}
                        selectEmployeeIdfn={selectEmployeeIdfn}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                        setEmployeeName={setEmployeeName}
                        selectBranchIdfn={selectBranchIdfn}
                        setButton1Disabled={setButton1Disabled}
                        setButton2Disabled={setButton2Disabled}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInputDisable
                        label="Employee Name"
                        name={employeeName}

                        // custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      {/* <CustomInput
                        label="Email"
                        name="email"
                       inputType={Email}
                       value={employee_email}
                       validate={validateEmail}
                       custPlaceholder=" " 
                        
                      /> */}

                      <CustomInputDisable
                        label="Email"
                        name={employeeEmail}

                        // custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Password"
                        name="password"
                        inputType={Password}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomDropdownMui
                        label="User Role"
                        name="role_id"
                        
                        custPlaceholder="Select Branch"
                        setFieldValue={setFieldValue}
                        options={UserRoleDrop}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                     <CustomRadioButton
                        label="Status"
                        name="active_status"
                        options={status}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",

                        marginTop: "5px",
                      }}
                    >
                      
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        alignItems: "end",
                        marginTop: "15px",
                      }}
                    >
                       <button
                        type="submit"
                        disabled={isSubmitting}
                        className="expense-submit-btn"
                      >
                        {changebtn ? "Submit" : "Update"}
                      </button>
                     
                      <button
                        type="button"
                        disabled={isSubmitting}
                        onClick={() => {
                          resetForm();
                          setchangebtn(true);
                        }}
                        className="expense-cancel-btn"
                        style={{ border: "1px solid var(--primary-color)" }}
                      >
                        Cancel
                      </button>
                    </Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12} sx={{}}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
              //   boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
              <CusTable
                  TableHeading={MASTER.UserMasterTableHeaders}
                  Tabledata={rowTableData}
                  TableTittle="Overview"
                  handleDelete={handleDelete}
                  setmyDefaultFieldValues={setmyDefaultFieldValues}
                  showAction={true}
                  showSearch={true}
                  //onViewClick={onViewClick}
                  handleViewClick={handleViewClick}
                />
              </Grid>
              {companyModel && (
                <NestedModal
                  open={companyModel}
                  onClose={() => setCompanyModel(false)}
                  id={selectedUserId}
                />
              )}
            </Grid>
          </Container>
        </Grid>
      </Grid>
      {/* </Grid> */}
    </div>
  );
};

export default UserMaster;