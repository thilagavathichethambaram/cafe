import { Container, Grid } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
// import "../Css/timesheet.css";
import { useDispatch, useSelector } from "react-redux";
import * as Yup from "yup";
import CustomDateInput from "../../../Components/CustomDate/CustomDateInput";
import CustomDropdownMui from "../../../Components/CustomDropDown/CustomDropdown";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import CustomPhoneNumber from "../../../Components/CustomPhoneNb/CustomPhoneNumber";

import { Email } from "@mui/icons-material";
import { Form, Formik } from "formik";
import CusTable from "../../../Components/CustomTable/CusTable";
import * as MASTER from "../../../Components/CustomTable/Tableentries";

import Toast from "../../../Components/Toast/Toaste";
import actions from "../../../ReduxStore/actions";
import FileUploadInput from "../../../Components/FileUpload/FileUpload";
const EmployeeMaster = () => {
  const dispatch = useDispatch();

  const [toastMessage, setToastMessage] = useState("");
  const [backColor, setBackColor] = useState("");
  const [showToast, setShowToast] = useState(false);
  const [changebtn, setchangebtn] = useState(true);
  const formikRef = useRef();
  const [companyModel, setCompanyModel] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState(null);
  const { EmployeeDelete } = useSelector((state) => state?.EmployeeDelete);
  const { EmployeeUpdate } = useSelector((state) => state?.EmployeeUpdate);
  const { EmployeeCreate } = useSelector((state) => state?.EmployeeCreate);

  ///////////GetById/////////////
  const { EmployeeGetById } = useSelector((state) => state?.EmployeeGetById);
  console.log(EmployeeGetById, "EmployeeGetById");
  // const setDefaultFieldValues = (id) => {
  //   const data = {
  //     data: {},
  //     method: "get",
  //     apiName: getAllBranches/${id},
  //   };
  //   dispatch(actions.EMPLOYEEGETBYID(data));
  //   const { setFieldValue } = formikRef.current;
  //   if (setFieldValue && EmployeeGetById?.data?.length) {
  //     setFieldValue("Branch_id", EmployeeGetById.data[0]?.Branch_id);

  //   }
  //   setchangebtn(false);
  // };
  /////////////////////
  const handleViewClick = (id) => {
    setSelectedCompanyId(id);
    setCompanyModel(true);
  };
  ////////////Create
  const handleSubmit = (values, { setSubmitting, resetForm }) => {
    // Handle form submission
    console.log(values);
    if (changebtn) {
      const data1 = {
        data: { ...values },
        method: "post",
        apiName: "createEmployeeMaster",
      };

      dispatch(actions.EMPLOYEECREATE(data1));

      const data = { data: {}, method: "get", apiName: "getAllEmployee" };
      dispatch(actions.EMPLOYEEGETALL(data));
    }

    /////////////////////
    else {
      const data2 = {
        data: { ...values },
        method: "put",
        apiName: `updateEmployeeMaster/${EmployeeGetById.data.employee_id}`,
      };

      dispatch(actions.EMPLOYEEUPDATE(data2));
      setchangebtn(true);
    }

    resetForm();
    setSubmitting(false);
  };

  //----------------------------------------------------------------------------------------

  const OnViewClick = (id) => {
    const data = {
      data: {},
      method: "get",
      apiName: `getEmployeeById/${id?.employee_id}`,
    };
    dispatch(actions.EMPLOYEEGetById(data)).then(() => {
      const EmployeeData = EmployeeGetById.data;
      if (formikRef.current && EmployeeData) {
        Object.keys(EmployeeData).forEach((key) => {
          formikRef.current.setFieldValue(key, EmployeeData[key]);
        });
      }
      setchangebtn(false);
    });
  };
  // /////delete
  const handleDelete = (id) => {
    const data = {
      data: {},
      method: "DELETE",
      apiName: `deleteEmployee/${id?.employee_id}`,
    };
    dispatch(actions.EMPLOYEEDELETE(data));

    //-------------------------------------------------------------------------------------------------

    const data1 = { data: {}, method: "get", apiName: "getEmployeeDetails" };
    dispatch(actions.EMPLOYEEGETALL(data1));
    if (EmployeeDelete?.data) {
      triggerToast("Successfully Deleted!");
      setBackColor("green");
    } else {
      triggerToast("failed");
      setBackColor("red");
    }
  };

  const triggerToast = (message) => {
    console.log(message, "toast work successfully");
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 3000); // Toast will disappear after 3 seconds
  };

  const { EmployeeGetAll } = useSelector((state) => state?.EmployeeGetAll);
  useEffect(() => {
    const data1 = { data: {}, method: "get", apiName: "getAllEmployee" };
    dispatch(actions.EMPLOYEEGETALL(data1));
  }, [dispatch]);

  const [rowTableData, setRowTableData] = useState([]);

  useEffect(() => {
    if (EmployeeGetAll?.data) {
      const tempArr1 = EmployeeGetAll.data.map((data, index) => ({
        Sno: index + 1,

        employee_name: data.employee_name,
        // employee_unique_id: data.employee_unique_id,
        employee_id: data.employee_id,
        designation_id: data.designation_name,
        employee_email: data.employee_email,
        branch_location: data.branch_location,
      }));

      setRowTableData(tempArr1);
    }
  }, [EmployeeGetAll]);
  ////////////////////////////////////////DropDown
  const { EmpBranchDropDown } = useSelector(
    (state) => state?.EmpBranchDropDown
  );
  // console.log(BranchDropDown, "BranchDropDownllllll");

  useEffect(() => {
    const data = { data: {}, method: "get", apiName: "branchDropDown" };
    dispatch(actions.EMPBRANCHDROPDOWN(data));
  }, [dispatch]);

  const [BranchDrop, setBranchDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    EmpBranchDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.branch_id,
        label: values?.branch_location,
      })
    );
    setBranchDrop(tempArr);
  }, [EmpBranchDropDown]);
  /////////////////////////DesginationDropDown
  const { DesginationDropDown } = useSelector(
    (state) => state?.DesginationDropDown
  );
  // console.log(BranchDropDown, "BranchDropDownllllll");

  useEffect(() => {
    const data = { data: {}, method: "get", apiName: "designationDropDown" };
    dispatch(actions.DESGINATIONDROPDOWN(data));
  }, [dispatch]);

  const [DesginationDrop, setDesginationDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    DesginationDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.designation_id,
        label: values?.designation_name,
      })
    );
    setDesginationDrop(tempArr);
  }, [DesginationDropDown]);
  const validationSchema = Yup.object().shape({
    branch_location: Yup.string().required("Branch is required"),
    designation_id: Yup.string().required("Designation is required"),
    employee_unique_id: Yup.string().required("Employee Id is required"),
    employee_name: Yup.string().required("Employee Name is required"),
    employee_email: Yup.string().required("Email is required"),
    employee_password: Yup.string().required("Password is required"),
    dob: Yup.string().required("DOB is required"),
    doj: Yup.string().required("DOJ is required"),
    mobile_number: Yup.string().required("Mobile Number is required"),
    adhaar_number: Yup.string().required("Adhaar Number is required"),
  });
  function validateEmail(value) {
    let error = "";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const allowedDomains = ["gmail.com", "yahoo.com", "outlook.com"];

    if (!value) {
      error = "Email is required";
    } else if (!emailRegex.test(value)) {
      error = "Invalid email address";
    } else {
      const domain = value.split("@")[1];
      if (!allowedDomains.includes(domain)) {
        error = "Email domain must be @gmail.com, @yahoo.com, or @outlook.com";
      }
    }
    return error;
  }

  return (
    <div style={{ height: "100%", width: "100%" }}>
      <Grid
        container
        md={12}
        style={{
          height: "100%",
        }}
      >
        {/* input field */}
        <Grid item md={12} sx={{ marginTop: "20px" }}>
          <Formik
            innerRef={formikRef}
            initialValues={{
              branch_id: "",
              designation_id: "",
              employee_unique_id: "",
              employee_name: "",
              employee_email: "",
              employee_password: "1234567890",
              dob: "",
              doj: "",
              mobile_number: "",
              adhaar_number: "",
            }}
            // style={{ height: "100%" }}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting, resetForm, setFieldValue }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "0px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  {/* heading Row */}
                  <Grid container sx={{ height: "100%" }}>
                    {/* First Row */}
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDropdownMui
                        label="Branch"
                        name="branch_id"
                        custPlaceholder=" "
                        setFieldValue={setFieldValue}
                        options={BranchDrop}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Employee Id"
                        name="employee_unique_id"
                        inputType={"text"}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Employee Name"
                        name="employee_name"
                        inputType={"text"}
                        custPlaceholder=" "
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomDropdownMui
                        label="Designation"
                        name="designation_id"
                        custPlaceholder=" "
                        setFieldValue={setFieldValue}
                        options={DesginationDrop}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Email"
                        name="employee_email"
                        inputType={Email}
                        custPlaceholder=" "
                        validate={validateEmail}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomPhoneNumber
                        label="Mobile Number"
                        name="mobile_number"

                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "Start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <FileUploadInput
                        label="Adhaar Number"
                        name="adhaar_number"
                        inputType={"number"}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDateInput
                        label="DOJ"
                        name="doj"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDateInput
                        label="DOB"
                        name="dob"
                        custPlaceholder=" "
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    ></Grid>
                    <Grid></Grid>
                    <Grid item xs={4}></Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        alignItems: "end",
                        marginTop: "15px",
                      }}
                    >
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="expense-submit-btn"
                      >
                        {changebtn ? "Submit" : "Update"}
                      </button>
                      <button
                        type="button"
                        disabled={isSubmitting}
                        onClick={() => {
                          resetForm();
                          setchangebtn(true);
                        }}
                        className="expense-cancel-btn"
                        style={{ border: "1px solid var(--primary-color)" }}
                      >
                        Cancel
                      </button>
                    </Grid>
                    <Grid item xs={4}></Grid>
                    <Grid></Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12} sx={{}}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
              //   boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.EmployeeMasterTableHeaders}
                  Tabledata={rowTableData}
                  TableTittle="Overview"
                  // showEmpDetails={true}
                  handleViewClick={handleViewClick}
                  showAction={true}
                  showSearch={true}
                  OnViewClick={OnViewClick}
                  setmyDefaultFieldValues={OnViewClick}
                  handleDelete={handleDelete}
                />
                {/* {modalOpen && <ModelOpen open={open} handleClose={handleClose} handleOpen={handleOpen}/>} */}
              </Grid>
            </Grid>
          </Container>
        </Grid>
      </Grid>
      {showToast && <Toast message={toastMessage} backColor={backColor} />}
    </div>
  );
};

export default EmployeeMaster;