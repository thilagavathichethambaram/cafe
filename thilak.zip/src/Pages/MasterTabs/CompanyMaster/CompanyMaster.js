import { Container, Grid } from "@mui/material";
import { Form, Formik } from "formik";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import CustomPhoneNumber from "../../../Components/CustomPhoneNb/CustomPhoneNumber";
import CusTable from "../../../Components/CustomTable/CusTable";
import * as MASTER from "../../../Components/CustomTable/Tableentries";
import actions from "../../../ReduxStore/actions";
import * as Yup from "yup";
import NestedModal from "../../../Components/EyeButton/EyeButton1";





const CompanyMaster = () => {
  const dispatch = useDispatch();
  const formikRef = useRef();

  const [companyModel, setCompanyModel] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState(null);

  const [changebtn, setchangebtn] = useState(true);
  const { CreateCompanyMaster } = useSelector(
    (state) => state?.CreateCompanyMaster
  );
  const { CompanyGetById } = useSelector((state) => state?.CompanyGetById);
  const { CompanyUpdate } = useSelector((state) => state?.CompanyUpdate);
  const { CompanyDelete } = useSelector((state) => state?.CompanyDelete);
  const { CompanyTableGetAll } = useSelector(
    (state) => state?.CompanyTableGetAll
  );

  const handleSubmit = (values, { setSubmitting, resetForm }) => {
    if (changebtn) {
      const data1 = {
        data: { ...values },
        method: "post",
        apiName: "createcompany",
      };
      dispatch(actions.CREATECOMPANYMASTER(data1));
      const data = { data: {}, method: "get", apiName: "getallcompanies" };
      // dispatch(actions.COMPANYTABLEGETALL(data));
    } else {
      const data2 = {
        data: { ...values },
        method: "put",
        apiName: `updatecompany/${CompanyGetById.data.company_id}`,
      };
      dispatch(actions.COMPANYUPDATE(data2));
      setchangebtn(true);
    }
    resetForm();
    setSubmitting(false);
  };

  const onViewClick = (id) => {
    const data = {
      data: {},
      method: "get",
      apiName: `getcompany/${id?.company_id}`,
    };
    dispatch(actions.COMPANYGetById(data)).then(() => {
      const companyData = CompanyGetById.data;
      if (formikRef.current && companyData) {
        Object.keys(companyData).forEach((key) => {
          formikRef.current.setFieldValue(key, companyData[key]);
        });
      }
      setchangebtn(false);
      
    });
  };

  const handleDelete = (id) => {
    const data = {
      data: {},
      method: "DELETE",
      apiName: `deletecompany/${id?.company_id}`,
    };
    dispatch(actions.COMPANYDELETE(data));
  };

  useEffect(() => {
    const data1 = { data: {}, method: "get", apiName: "getallcompanies" };
    dispatch(actions.COMPANYTABLEGETALL(data1));
  }, [dispatch, CreateCompanyMaster, CompanyUpdate, CompanyDelete]);

  const [rowTableData, setRowTableData] = useState([
    {
      Sno: "1",
      Company: "--",
      Street_Building: "--",
      City_State_Pincode: "--",
      Country: "--",
    },
  ]);

  useEffect(() => {
    const tempArr1 = [];
    CompanyTableGetAll?.data?.map((data, index) => {
      return tempArr1.push({
        Sno: index + 1,
        company_id: data.company_id,
        company_name: data.company_name,
        street: data.street,
        address: data.address,
        country: data.country,
      });
    });
    setRowTableData(tempArr1);
  }, [CompanyTableGetAll]);

  const handleViewClick = (id) => {
    setSelectedCompanyId(id);
    setCompanyModel(true);
  };

  const validationSchema = Yup.object().shape({
    company_name: Yup.string().required("Company Name is required"),
    company_email: Yup.string().required("Company Email is required"),
    company_registration_no: Yup.string().required("Company Registration Number is required"),
    landline_no: Yup.string().required("Landline Number is required"),
    contact_person_name: Yup.string().required("Contact Person Name is required"),
    contact_person_phno: Yup.string().required("Contact Person Number is required"),
    contact_person_email: Yup.string().required("Contact Person Email is required"),
    street: Yup.string().required("Street is required"),
    city: Yup.string().required("City is required"),
    state: Yup.string().required("State is required"),
    country: Yup.string().required("Country is required"),
    pin_code: Yup.string().required("Pincode is required"),
  });
  function validateEmail(value) {
    let error = "";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const allowedDomains = ["gmail.com", "yahoo.com", "outlook.com"];

    if (!value) {
      error = "Email is required";
    } else if (!emailRegex.test(value)) {
      error = "Invalid email address";
    } else {
      const domain = value.split("@")[1];
      if (!allowedDomains.includes(domain)) {
        error = "Email domain must be @gmail.com, @yahoo.com, or @outlook.com";
      }
    }
    return error;
  }

  return (
    <div style={{ height: "100%", width: "100%" }}>
      <Grid container md={12} style={{ height: "100%" }}>
        <Grid item md={12} sx={{ marginTop: "20px" }}>
          <Formik
            innerRef={formikRef}
            initialValues={{
              company_name: "",
              company_email: "",
              company_registration_no: "",
              landline_no: "",
              contact_person_name: "",
              contact_person_phno: "",
              contact_person_email: "",
              street: "",
              city: "",
              state: "",
              country: "",
              pin_code: "",
            }}
            onSubmit={handleSubmit}
            validationSchema={validationSchema}
          >
            {({ isSubmitting, resetForm }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "0px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  <Grid container sx={{ height: "100%" }}>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Company Name"
                        name="company_name"
                        inputType="text"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Company Registration Number"
                        name="company_registration_no"
                        inputType="Number"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Company Email"
                        name="company_email"
                        inputType="email"
                        validate={validateEmail}
                        custPlaceholder=" "
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Contact Person Name"
                        name="contact_person_name"
                        inputType="text"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomPhoneNumber
                        label="Contact Person Number"
                        name="contact_person_phno"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Contact Person Email"
                        name="contact_person_email"
                        inputType="email"
                        validate={validateEmail}
                        custPlaceholder=" "
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Street"
                        name="street"
                        inputType="text"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="City"
                        name="city"
                        inputType="text"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="State"
                        name="state"
                        inputType="text"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Country"
                        name="country"
                        inputType="text"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomInput
                        label="Pincode"
                        name="pin_code"
                        inputType="number"
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomPhoneNumber
                        label="Landline Number"
                        name="landline_no"
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    ></Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    ></Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        alignItems: "center",
                        marginTop: "15px",
                      }}
                    >
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="expense-submit-btn"
                      >
                        {changebtn ? "Submit" : "Update"}
                      </button>
                      <button
                        type="button"
                        disabled={isSubmitting}
                        onClick={() => {
                          resetForm();
                          setchangebtn(true);
                        }}
                        className="expense-cancel-btn"
                        style={{ border: "1px solid var(--primary-color)" }}
                      >
                        Cancel
                      </button>
                    </Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.CompanyMasterTableHeaders}
                  Tabledata={rowTableData}
                  TableTittle="Overview"
                  handleDelete={handleDelete}
                  setmyDefaultFieldValues={onViewClick}
                  showAction={true}
                  showSearch={true}
                  onViewClick={onViewClick}
                  handleViewClick={handleViewClick}
                />
              </Grid>
              {companyModel && (
                <NestedModal
                  open={companyModel}
                  onClose={() => setCompanyModel(false)}
                  id={selectedCompanyId}
                />
              )}
            </Grid>
          </Container>
        </Grid>
      </Grid>
    </div>
  );
};

export default CompanyMaster;