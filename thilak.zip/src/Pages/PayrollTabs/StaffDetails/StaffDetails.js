import React, { useState, useEffect, useRef } from "react";
import { Container, Grid } from "@mui/material";
// import "../Css/timesheet.css";
// import userIcon from "../../../Assets/user.png";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import CustomDropdownMui from "../../../Components/CustomDropDown/CustomDropdown";
// import CustomDateInput from "../../../Components/CustomDate/CustomDateInput";
import actions from "../../../ReduxStore/actions/index"
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form } from "formik";
import CusTable from "../../../Components/CustomTable/CusTable";
import * as MASTER from "../../../Components/CustomTable/Tableentries";
// import CustomInputDisable from "../../Components/CustomInputDisable/CustomInputDisable";
// import "./Timesheet";
import CustomInputDisable from "../../../Components/CustomInputDisable/CustomInputDisable";


const StaffDetails = () => {


  const dispatch = useDispatch();
  ////////////////////BranchDropDown
  const { UserMasterBranchDropDown } = useSelector(
    (state) => state?.UserMasterBranchDropDown
  );
  // console.log(BranchDropDown, "BranchDropDownllllll");

  useEffect(() => {
    const data = { data: {}, method: "get", apiName: "branchDropDown" };
    dispatch(actions.USERMASTERBRANCHDROPDOWN(data));
  }, [dispatch]);

  const [branchDrop, setBranchDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserMasterBranchDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.branch_id,
        label: values?.branch_location,
      })
    );
    setBranchDrop(tempArr);
  }, [UserMasterBranchDropDown]);

  const [branchVal, setBranchVal] = useState(null);
  console.log("selectedValue", branchVal);

  const handleDrop = (name, selectedValue) => {
    setBranchVal(selectedValue);
  };
  /////////////////////////////empBranchDropDown
  const { UserEmployeeDropDown } = useSelector(
    (state) => state?.UserEmployeeDropDown
  );
  console.log(UserEmployeeDropDown, "BranchDropDownllllll");


  const [EmployeeDrop, setEmployeeDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserEmployeeDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.employee_id,
        label: values?.employee_unique_id,
      })
    );
    setEmployeeDrop(tempArr);
  }, [UserEmployeeDropDown]);
 

  const [employeeValue, setEmployeeValue] = useState("");
  useEffect(() => {
    // if(employeeValue){
    const data = {
      data: {},
      method: "get",
      apiName: "employeeDetailsForUserMaster",
    };
    // dispatch(actions.USERDROPDOWN(data));
    // }
  }, [employeeValue, dispatch]);

  const employeeDropDown = (selectedValue) => {
    alert("yyy");
    console.log("employeeDropDown", selectedValue);
    setEmployeeValue(selectedValue);
  };

 
  const [employeeVal, setemployeeVal] = useState(null);
  console.log("selectedValue", employeeVal);

  ////////////////////
  const [employeeName, setEmployeeName] = useState(" ");
  const [empId, setEmpId] = useState("");
  console.log("employeeName",employeeName,empId);
  const [employeeEmail, setEmployeeEmail] = useState(" ");
  const [button1Disabled, setButton1Disabled] = useState(false);
  const [button2Disabled, setButton2Disabled] = useState(false);

  

  const selectEmployeeIdfn = async (name, id, email) => {
    setEmpId(id)
  };
  ////////////////
  
  useEffect(()=>{
    if(empId){
      const getemp_name = UserEmployeeDropDown?.data?.filter(
        (data) => data.employee_id == empId
      );
      setEmployeeName(getemp_name[0].employee_name);
      setEmployeeEmail(getemp_name[0].employee_email);
    }
  },[empId])
  

  ////////////
  const useraccess = [
    { label: "All", value: "All" },
    { label: "Branch", value: "Branch" },
  ];
  const status = [
    { label: "Active", value: "All" },
    { label: "Inactive", value: "Branch" },
  ];
  function validateEmail(value) {
    let error = "";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const allowedDomains = ["gmail.com", "yahoo.com", "outlook.com"];

    if (!value) {
      error = "Email is required";
    } else if (!emailRegex.test(value)) {
      error = "Invalid email address";
    } else {
      const domain = value.split("@")[1];
      if (!allowedDomains.includes(domain)) {
        error = "Email domain must be @gmail.com, @yahoo.com, or @outlook.com";
      }
    }
    return error;
  }

  useEffect(() => {
    if (branchVal) {
      const data3 = {
        data: { branch_id: branchVal },
        method: "post",
        apiName: "getEmployeesByBranchId",
      };
      dispatch(actions.USEREMPLOYEEDROPDOWN(data3));
    }
  }, [branchVal, dispatch]);

  ////////////////
  const [BranchDropDownIdSelect, setBranchDropDownIdSelect] = useState("");
  const selectBranchIdfn = (name, id) => {
    console.log(name, "selectBranchIdfn");
    console.log(id, "selectBranchIdfn");
    setBranchDropDownIdSelect(id);

    const data3 = {
      data: { branch_id: branchVal },
      method: "post",
      apiName: "getEmployeesByBranchId",
    };
    // dispatch(actions.USEREMPLOYEEDROPDOWN(data3));
  };

  const [BranchEmployeeDrop, setBranchEmployeeDrop] = useState([]);
  useEffect(() => {
    const tempArr = [];
    UserEmployeeDropDown?.data?.map((values, index) =>
      tempArr.push({
        value: values?.employee_id,
        label: values?.employee_unique_id,
      })
    );
    setBranchEmployeeDrop(tempArr);
  }, [UserEmployeeDropDown]);
  return (
    <div style={{ height: "100%", width: "100%" }}>
      <Grid
        container
        md={12}
        style={{
          height: "100%",
        }}
      >
        {/* input field */}
        <Grid item md={12} sx={{  marginTop: "20px" }}>
          <Formik
            initialValues={{
              emp_id: "",
              employee_name: "",
            }}
            style={{ height: "100%" }}
            //   onSubmit={handleSubmit}
          >
            {({ isSubmitting, resetForm, setFieldValue }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "10px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  {/* heading Row */}
                  <Grid container sx={{ height: "100%" }}>

                  <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                       
                      }}
                    >
                         <CustomDropdownMui
                        label="Branch"
                        name="Branch"
                        custPlaceholder="Select Branch"
                        setFieldValue={setFieldValue}
                        options={branchDrop}
                        selectEmployeeIdfn={handleDrop}
                        // selectBranchIdfn={selectBranchIdfn}
                      />
                   
                    
                    </Grid>
                    {/* First Row */}
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                       
                      }}
                    >
                        <CustomDropdownMui
                        label="Employee Id"
                        name="Employee Id"
                        custPlaceholder=""
                        setFieldValue={setFieldValue}
                        // selectEmployeeIdfn={selectEmployeeIdfn}

                        options={EmployeeDrop}
                        // selectEmployeeIdfn={employeeDropDown}
                        selectEmployeeIdfn={selectEmployeeIdfn}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                        setEmployeeName={setEmployeeName}
                        selectBranchIdfn={selectBranchIdfn}
                        setButton1Disabled={setButton1Disabled}
                        setButton2Disabled={setButton2Disabled}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                       
                      }}
                    >
                       <CustomInputDisable
                        label="Employee Name"
                        name={employeeName}

                        // custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                       
                      }}
                    >
                     <CustomInputDisable
                        label="designation"
                        name={employeeEmail}

                        // custPlaceholder=" "
                      />
                    
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        
                      }}
                    >
                      <CustomInput
                        label="Wages"
                        name="Wages"
                        inputType={"text"}
                        custPlaceholder=" "
                        showtextPlaceholder={true} // or false based on your requirement
                        textPlaceholder="/hour"
                      />
                    </Grid>
                    
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        alignItems: "center",
                      }}
                    >
                      <button
                        type="submit"
                        //   disabled={isSubmitting}
                        // onClick={() => setDefaultFieldValues(setFieldValue)}
                        className="expense-submit-btn"
                      >
                        Submit
                      </button>

                      <button
                        type="button"
                        onClick={() => {}}
                        className="expense-cancel-btn"
                        style={{ border: "1px solid var(--primary-color)" }}
                      >
                        Cancel
                      </button>
                    </Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12} sx={{}}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
              //   boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.StaffDetailsTableHeaders}
                  Tabledata={MASTER.StaffDetailsTableValues}
                  TableTittle="Overview"
                  showEmpDetails={false}
                  // handleDeleteIdChange={handleDeleteIdChange}
                />
              </Grid>
            </Grid>
          </Container>
        </Grid>
      </Grid>
      {/* {showToast && (
        <Toast message={toastMessage} backColor={backColor}/>
      )} */}
    </div>
  );
};

export default StaffDetails;
