export const adminUrl = "http://122.165.52.124:5500/api/v1/"; 
export const loginUrl = "";
