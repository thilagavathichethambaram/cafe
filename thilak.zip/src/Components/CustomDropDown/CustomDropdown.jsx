// CustomDropdownMui.js
import React, { useState } from "react";
import { ErrorMessage, Field } from "formik";
import Select from "react-select";
import MenuItem from "@mui/material/MenuItem";
// import Select from "@mui/material/Select";
import "./CustomDropdownMui.css";
import "../ComponentsCss/componet.css";
import { InputLabel } from "@mui/material";


const CustomDropdownMui = ({
  label,
  name,
  options,
  custPlaceholder,
  setFieldValue,
  selectEmployeeIdfn,
  selectCategoryIdfn,
  selectBranchIdfn,
  setEmployeeName,
  setButton1Disabled,
  setButton2Disabled,

  ...rest
}) => { 
  const [inputValue, setInputValue] = useState('');

  const handleInputChange = (value) => {
    setInputValue(value);
  };



  return (
    <div style={{ width: "85%" }}>
      <div>
        <label htmlFor={name} className="input-heading">
          {label}
        </label>
      </div>
      <Field
        as="select"
        id={name}
        name={name}
        {...rest}
        className="customDropdown-input"
        menuIsOpen={inputValue.length > 0} 
        onInputChange={handleInputChange}
        filterOption={(option, inputValue) =>
          option.label.toLowerCase().includes(inputValue.toLowerCase())
        }
        
        // onChange={(e) => {
        //   form.setFieldValue(name, e.target.value);
        // }}
        onChange={(option) => {
          // Use the setFieldValue passed from props
          setInputValue('');
          setFieldValue(name, option.target.value);
          // Log the selected value
          console.log(name,option.target.value);

          if (selectEmployeeIdfn) {
            selectEmployeeIdfn(name,option.target.value)

          }
          if (selectCategoryIdfn) {
            selectCategoryIdfn(name,option.target.value)

          }
          if (selectBranchIdfn) {
            selectBranchIdfn(name,option.target.value)

          }
        
          if(!option){
            setEmployeeName(' ')
            setButton1Disabled(true)
            setButton2Disabled(true)
            }

        }}
        components={{
          DropdownIndicator: null,
        }}
      >
        {custPlaceholder && (
          <option value="" disabled className="customDropdown-disabled-option">
            {custPlaceholder ? custPlaceholder : "Select dropddown"}
          </option>
        )}
        {options?.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </Field>
      <ErrorMessage name={name} component="div" className="inputs-error-msg" />
    </div>
  );
};

export default CustomDropdownMui;
