export const CreateEmployeeTableHeaders = [
  "S.No",
  "Employee Name",
  "Employee Id",
  "Check-In Date",
  "Check-In Time",
  "Check-Out Date",
  "Check-Out Time",
  "Status",
];

export const ListofLogsTableHeaders = [
  "S.No",
  "Check-In Date",
  "Check-In Time",
  "Check-Out Date",
  "Check-Out Time",
  "Working Hours",
];

export const HoursRecordTableHeaders = [
  "S.No",
  "Check-In Date",

  "Check-Out Date",
  "Working Hours",
];

export const BranchMasterTableHeaders = [
  "S.No",

  "Branch Location",
  "Street/Building",
  "City/State/Pincode",
  "Country",
  "Action",
];
export const EmployeeMasterTableHeaders = [
  "S.No",
  "Name",
  "Id",
  "Designation",
  "Email",
  "Branch",
  "Action",
];

export const EntryManagementTableHeaders = [
  "S.No",
  "Branch",
  "Employee Name",
  "Employee Id",
  "Check-In Date",
  "Check-In Time",
  "Check-Out Date",
  "Check-Out Time",
  "Status",
  "Action",
];

export const StaffDetailsTableHeaders = [
  "S.No",
  "Employee Name",
  "Employee Id",
  "Wages",
];

export const CompanyMasterTableHeaders = [
  "S.No",

  "Company",

  "Street/Building",
  "City/State/Pincode",
  "Country",
  "Action",
];
export const PayslipTableHeaders = [
  "S.No",
  "Branch",
  "Employee Name",
  "Employee Id",
  "Advance Amount",
  "Advance Detected",
  "Actual Wages Paid",
  "Voucher Number",
  "Action"
];
export const AdvanceRegisterTableHeaders = [
  "S.No",
  "Branch",
  "Employee Id",
  "Employee Name",
  "Date of Detected",
  "Detected Advance",
  "Balance Amount",
  "Voucher Number",
  "Status",
  
];
export const UserMasterTableHeaders = [
  "S.No",
 "Branch",
  "Id",
  "Name",
  "Email",
  "User Role",
  "Status",
  "Action",
];
export const RoleMasterTableHeaders = [
  "S.No",
 "User ID ",
 "User Role",
 "Status"
];
export const AdvanceRepaidTableHeaders = [
  "S.No",
 "Branch ",
 "Employee Id",
 "Employee Name",
 "Advance Amount",
 "Date of Repayment",
 "Advance Repay Amount",
 "Balance Amount",
 "Receipt Number",
];
export const AdvancePaidTableHeaders = [
  "S.No",
 "Branch ",
 "Employee Id",
 "Employee Name",
 "Date of Advance",
 "Advance Amount",
 "Voucher Number",
 "Action",
];
export const RoleMasterTableValues = [
  {
    Sno: "1",
    RoleId:"3",
    UserRole:"BranchManager",
    Status:"Active"
   
  },];
export const EmployeeMasterTableValues = [
  {
    Sno: "1",
    EmployeeName: "Biddu",
    EmployeeId: "001",
    Designation: "Admin",

    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "2",
    EmployeeName: "Pravin M",
    EmployeeId: "002",
    Designation: "Employee",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "3",
    EmployeeName: "Pravin R",

    EmployeeId: "003",
    Designation: "Employee",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "4",
    EmployeeName: "Valla",

    EmployeeId: "004",
    Designation: "Employee",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "5",
    EmployeeName: "Arun",

    EmployeeId: "006",
    Designation: "Manager",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "6",
    EmployeeName: "Dinesh",

    EmployeeId: "006",
    Designation: "Employee",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "7",
    EmployeeName: "Binu",

    EmployeeId: "007",
    Designation: "Employee",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
  {
    Sno: "8",
    EmployeeName: "Raj",

    EmployeeId: "008",
    Designation: "Employee",
    E_Mail: "teaboy123@gmail.com",
    Branch: "6th Main Rd,V Block,Anna Nagar",
  },
];

export const BranchMasterTableValues = [
  {
    Sno: "1",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "2",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "3",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "4",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "5",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "6",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "7",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
  {
    Sno: "8",

    Branch_Location: "Anna Nagar",
    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
];
export const HoursRecordTableValues = [
  {
    Sno: "1",
    Check_In_Date: "19 April 2023",
    Check_Out_Date: "19 April 2023",
    Working_Hours: "12:00",
  },
  {
    Sno: "2",
    Check_In_Date: "20 April 2023",
    Check_Out_Date: "20 April 2023",
    Working_Hours: "12:00",
  },
  {
    Sno: "3",
    Check_In_Date: "21 April 2023",
    Check_Out_Date: "21 April 2023",
    Working_Hours: "12:00",
  },
  {
    Sno: "4",
    Check_In_Date: "22 April 2023",
    Check_Out_Date: "22 April 2023",
    Working_Hours: "12:00",
  },
  {
    Sno: "5",
    Check_In_Date: "23 April 2023",
    Check_Out_Date: "23 April 2023",
    Working_Hours: "12:00",
  },
  {
    Sno: "6",
    Check_In_Date: "24 April 2023",
    Check_Out_Date: "24 April 2023",
    Working_Hours: "12:00",
  },
  {
    Sno: "7",
    Check_In_Date: "25 April 2023",
    Check_Out_Date: "25 April 2023",

    Working_Hours: "12:00",
  },
];

export const ListOfLogTableValues = [
  {
    Sno: "1",
    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
  {
    Sno: "2",
    Check_In_Date: "20 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "20 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
  {
    Sno: "3",
    Check_In_Date: "21 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "21 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
  {
    Sno: "4",
    Check_In_Date: "22 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "22 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
  {
    Sno: "5",
    Check_In_Date: "23 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "23 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
  {
    Sno: "6",
    Check_In_Date: "24 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "24 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
  {
    Sno: "7",
    Check_In_Date: "25 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "25 April 2023",
    Check_Out_Time: "11:00",
    Working_Hours: "12:00",
  },
];

export const CreateEmployeeTableValues = [
  {
    Sno: "1",
    EmployeeId: "001",
    EmployeeName: "Biddu",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "2",
    EmployeeId: "002",
    EmployeeName: "Pravin M",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "3",
    EmployeeId: "003",
    EmployeeName: "Pravin R",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "4",
    EmployeeId: "004",
    EmployeeName: "Valla",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "5",
    EmployeeId: "006",
    EmployeeName: "Arun",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "6",
    EmployeeId: "006",
    EmployeeName: "Dinesh",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "7",
    EmployeeId: "007",
    EmployeeName: "Binu",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "8",
    EmployeeId: "008",
    EmployeeName: "Raj",

    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
];

export const EntryManagementTableValues = [
  {
    Sno: "1",
    Branch: "chennai",
    EmployeeName: "Biddu",
    EmployeeId: "001",
    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
  {
    Sno: "2",
    Branch: "chennai",
    EmployeeName: "parvin",
    EmployeeId: "001",
    Check_In_Date: "19 April 2023",
    Check_In_Time: "07:00",
    Check_Out_Date: "19 April 2023",
    Check_Out_Time: "11:00",
    Status: "Out",
  },
];

export const StaffDetailsTableValues = [
  {
    "S.No": 1,
    "Employee Name": "pravin",
    "Employee Id": "01",
    Wages: "$100",
  },
  {
    "S.No": 2,
    "Employee Name": "pravin",
    "Employee Id": "01",
    Wages: "$100",
  },
];

export const CompanyMasterTableValues = [
  {
    Sno: "1",
    Company: "Empty Cafe",

    Street_Building: "6th Main Rd,V Block,Anna Nagar",
    City_State_Pincode: "Chennai,Tamil Nadu 600014",
    Country: "India",
  },
];
export const PayslipTableValues = [
  {
    "S.No": 1,
    "Branch":"Ambatur",
    "Employee Name": "pravin",
    "Employee Id": "01",
    "Advance Amount":"20,000",
    "Advance Detected":"5000",
    "Actual Wages Paid":"20,000",
    "Voucher Number":"150",
    
    
  },
  {
    "S.No": 2,
    "Branch":"Chennai",
    "Employee Name": "Joshuva",
    "Employee Id": "28",
    "Advance Amount":"16,000",
    "Advance Detected":"1000",
    "Actual Wages Paid":"18,000",
    "Voucher Number":"130",
  },
];
export const AdvanceRegisterTableValues = [
  {
    "S.No":"1",
  "Branch":"Anna Nagar",
  "Employee Id":"001",
  "Employee Name":"joshuva",
  "Date of Detected":"04 Jan 2024",
  "Detected Advance":"4,000",
  "Balance Amount":"16,000",
  "Voucher Number":"140",
  "Status":"Paid"
    
    
  },
  {
    "S.No":"2",
  "Branch":"Ambatur",
  "Employee Id":"005",
  "Employee Name":"Deepak",
  "Date of Detected":"05 Feb 2024",
  "Detected Advance":"8,000",
  "Balance Amount":"22,000",
  "Voucher Number":"160",
  "Status":"Paid"
  },
];
export const UserMasterTableValues = [
  {
    Sno: "1",
    Branch: "Mohan&Co",
    Id: "78",
    Name: "subiii",
    UserRole: "Branch Master",
    Email: "subi@gmail.com",
    UserAccess:"Branch",
    Status:"Active",

  },
  {
    Sno: "1",
    Branch: "Mohan&Co",
    Id: "78",
    Name: "josva",
    UserRole: "Branch Master",
    Email: "josva@gmail.com",
    UserAccess:"Branch",
    Status:"Active",
  },
];
export const AdvancePaidTableValues = [
  {
    "S.No":"1",
 "Branch" :"Anna Nagar",
 "Employee Id":"001",
 "Employee Name":"Joshuva",
 "Date of Advance":"21 Dec 2023",
 "Advance Amount":"20,000",
 "Voucher Number":"140",
 
  },
];
export const AdvanceRepaidTableValues = [
  {
    "S.No":"1",
 "Branch ":"Anna Nagar",
 "Employee Id":"001",
 "Employee Name":"Joshuva",
 "Advance Amount":"20,000",
 "Date of Repayment":"04 Jan 2024",
 "Advance Repay Amount":"4,000",
 "Balance Amount":"16,000",
 "Receipt Number":"2452",
  },
];

