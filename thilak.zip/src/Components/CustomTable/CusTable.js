import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import React, { useState } from "react";
import { GrFormNext, GrFormPrevious } from "react-icons/gr";
import { IoTrash } from "react-icons/io5";
import { RiEdit2Line, RiSearchLine } from "react-icons/ri";

import "./CusTable.css";

const CusTable = ({
  TableHeading,
  Tabledata,
  TableTittle,
  showEmpDetails,
  showToatalHours,
  showAction,
  showSearch,
  handleViewClick,
  handleDelete,
  setmyDefaultFieldValues,
}) => {
  const recordperpage = 5;
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");

  const prepage = () => {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const changeCPage = (id) => {
    setCurrentPage(id);
  };

  const Nextpage = () => {
    const totalPages = Math.ceil(filteredRecords.length / recordperpage);
    if (currentPage !== totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
    setCurrentPage(1); // Reset to the first page when search query changes
  };

  const filteredRecords = Tabledata.filter((record) => {
    return Object.values(record).some((value) => {
      if (typeof value === "string") {
        return value.toLowerCase().includes(searchQuery.toLowerCase());
      }
      return false;
    });
  });

  const lastindex = currentPage * recordperpage;
  const fisrtindex = lastindex - recordperpage;
  const records = filteredRecords.slice(fisrtindex, lastindex);
  const npage = Math.ceil(filteredRecords.length / recordperpage);
  const numbers = [...Array(npage + 1).keys()].slice(1);

  console.log(records, "recordsssssssssssssssssssssssssss");

  return (
    <Grid container xs={12} sx={{ width: "100%" }}>
      <Grid
        item
        xs={12}
        style={{
          backgroundColor: "white",
          width: "100%",
          padding: "15px",
          borderRadius: "15px",
        }}
      >
        <Grid container className="table_search_grid">
          {!showSearch && (
            <Grid item xs={12}>
              <h3
                className="Table_heading"
                style={{
                  fontSize: "19px",
                  color: "var(--primary-color)",
                  marginBottom: "20px",
                }}
              >
                {TableTittle}
              </h3>
            </Grid>
          )}
          {showSearch && (
            <>
              <Grid item xs={4}>
                <h3
                  className="Table_heading"
                  style={{
                    fontSize: "19px",
                    color: "var(--primary-color)",
                    marginBottom: "20px",
                  }}
                >
                  {TableTittle}
                </h3>
              </Grid>
              <Grid item xs={6}></Grid>
              <Grid
                item
                xs={2}
                mb={1}
                sx={{
                  display: "flex",
                  justifyContent: "end",
                }}
              >
                <div className="search-container">
                  <RiSearchLine className="search-icon" />
                  <input
                    type="text"
                    placeholder="Search"
                    className="Table_search_input"
                    onChange={handleSearchChange}
                  />
                </div>
              </Grid>
            </>
          )}
        </Grid>

        {showEmpDetails && (
          <Grid
            xs={12}
            style={{ display: "flex", color: "var(--primary-color)" }}
          >
            <Grid xs={6} style={{ display: "flex" }}>
              <Grid xs={2.5}>
                <p>Employee Id</p>
              </Grid>
              <Grid xs={3.5}>
                <p>001</p>
              </Grid>
            </Grid>
            <Grid xs={6} style={{ display: "flex" }}>
              <Grid xs={3}>
                <p>Employee Name </p>
              </Grid>
              <Grid xs={3}>
                <p>Biddu</p>
              </Grid>
            </Grid>
          </Grid>
        )}

        <Grid item xs={12}>
          <Box
            mt={2}
            mb={2}
            sx={{ marginBottom: "0", marginTop: "0", height: "198px" }}
          >
            <table
              className="table table-borderless custom-table"
              style={{ width: "100%", borderCollapse: "collapse" }}
            >
              <thead>
                <tr>
                  {TableHeading.map((data) => (
                    <th
                      key={data}
                      scope="col"
                      className="thead_data"
                      style={{
                        color: "white",
                        backgroundColor: "var(--primary-color)",
                        fontWeight: 700,
                        fontSize: "13.8px",
                        borderBottom: "2px solid rgba(88, 68, 53, 0.23)",
                      }}
                    >
                      {data}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {records.map((datas, i) => (
                  <tr key={i}>
                    {Object.keys(datas).map(
                      (key) =>
                        key !== "id" &&
                        key !== "company_id" &&
                        key !== "branch_id" &&
                        key !== "user_id" && (
                          <td
                            key={key}
                            style={{
                              fontWeight: "600",
                              borderBottom: "2px solid rgba(88, 68, 53, 0.23)",
                              color: "#262323d9",
                              fontSize: "13px",
                            }}
                          >
                            {datas[key]}
                          </td>
                        )
                    )}
                    {showAction && (
                      <td
                        style={{
                          borderBottom: "2px solid rgba(88, 68, 53, 0.23)",
                          display: "flex",
                          alignItems: "center",
                        }}
                      >
                        <img
                         src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2220%22%20height%3D%2218%22%20viewBox%3D%220%200%2020%2018%22%3E%3Cpath%20id%3D%22Path_55812%22%20data-name%3D%22Path%2055812%22%20d%3D%22M11.182%2C3c4.984%2C0%2C9.131%2C3.88%2C10%2C9-.869%2C5.12-5.016%2C9-10%2C9s-9.131-3.88-10-9C2.051%2C6.88%2C6.2%2C3%2C11.182%2C3Zm0%2C16a8.495%2C8.495%2C0%2C0%2C0%2C8.113-7%2C8.495%2C8.495%2C0%2C0%2C0-8.113-7%2C8.495%2C8.495%2C0%2C0%2C0-8.113%2C7A8.495%2C8.495%2C0%2C0%2C0%2C11.182%2C19Zm0-2.5A4.34%2C4.34%2C0%2C0%2C1%2C7.022%2C12a4.34%2C4.34%2C0%2C0%2C1%2C4.16-4.5A4.34%2C4.34%2C0%2C0%2C1%2C15.341%2C12%2C4.34%2C4.34%2C0%2C0%2C1%2C11.182%2C16.5Zm0-2A2.411%2C2.411%2C0%2C0%2C0%2C13.492%2C12a2.411%2C2.411%2C0%2C0%2C0-2.311-2.5A2.411%2C2.411%2C0%2C0%2C0%2C8.871%2C12%2CA2.411%2C2.411%2C0%2C0%2C0%2C11.182%2C14.5Z%22%20transform%3D%22translate(-1.182%20-3)%22%20fill%3D%22%2312a8f3%22%2F%3E%3C%2Fsvg%3E"
                         alt="Custom SVG Image"
                          onClick={() => handleViewClick(datas)}
                          style={{width: '20px', height: '20px'}}
                        />
                        {/* <EyeButton
                          // onClick
                          // onClick={() => onViewClick(datas)}
                           onClick={()=>onViewClick(datas)
                            
                           }
                          id={datas}
                        /> */}
                        {/* <MdOutlineRemoveRedEye
                          onClick={() => <eyeButton></eyeButton>}
                          style={{
                            marginRight: "7px",
                            color: "blue",
                            cursor: "pointer",
                            fontSize: "20px",
                            border: "none",
                          }}
                        /> */}
                        {/* <EyeButton onClick={handleOpen}>
                          <VisibilityIcon sx={{ color: "blue" }} />
                        </EyeButton> */}

                        <RiEdit2Line
                          onClick={() => setmyDefaultFieldValues(datas)}
                          style={{
                            marginRight: "7px",
                            color: "green",
                            cursor: "pointer",
                            fontSize: "20px",
                            border: "none",
                          }}
                        />

                        <IoTrash
                          onClick={(id) => handleDelete(datas)}
                          style={{
                            color: "red",
                            cursor: "pointer",
                            fontSize: "20px",
                          }}
                        />
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </Box>
        </Grid>
      </Grid>

      {showToatalHours && (
        <Grid
          xs={12}
          style={{
            display: "flex",
            justifyContent: "end",
            marginLeft: "10%",
            color: "var(--primary-color)",
          }}
        >
          <Grid xs={4}>
            <p style={{ fontWeight: "700", fontSize: "23px" }}>Total Hours</p>
          </Grid>
          <Grid xs={4}>
            <p style={{ fontWeight: "700", fontSize: "23px" }}>62:00</p>
          </Grid>
        </Grid>
      )}

      <Grid item xs={12}>
        <Box style={{ marginTop: "10px" }}>
          <nav
            className="nav_pagination"
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <p
              style={{
                color: "#242020",
                fontSize: "13px",
                marginLeft: "3%",
                fontWeight: "600",
              }}
            >
              Showing {fisrtindex + 1}-
              {Math.min(lastindex, filteredRecords.length)} of{" "}
              {filteredRecords.length}
            </p>
            <ul className="pagination">
              <li className="page-item">
                <button
                  className="page-link"
                  href="#"
                  aria-label="Previous"
                  onClick={prepage}
                  style={{ marginTop: "-9px" }}
                >
                  <GrFormPrevious />
                </button>
              </li>
              {numbers.map((n, i) => (
                <li
                  className={`page-item ${currentPage === n ? "active" : ""}`}
                  key={i}
                >
                  <button
                    className="page-link"
                    href="#"
                    onClick={() => changeCPage(n)}
                    style={{
                      backgroundColor:
                        currentPage === n ? "var(--primary-color)" : "",
                      color: currentPage === n ? "white" : "",
                      padding: "2px  10px",
                      borderRadius: "12px",
                      fontSize: "10px",
                    }}
                  >
                    {n}
                  </button>
                </li>
              ))}
              <li className="page-item">
                <button
                  className="page-link"
                  href="#"
                  aria-label="Previous"
                  onClick={Nextpage}
                  style={{ marginTop: "-9px" }}
                >
                  <GrFormNext style={{ fontSize: "17px" }} />
                </button>
              </li>
            </ul>
          </nav>
        </Box>
      </Grid>
    </Grid>
  );
};

export default CusTable;
