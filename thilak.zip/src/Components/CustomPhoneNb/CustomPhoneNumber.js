import React from "react";
import { Field, ErrorMessage, useFormikContext } from "formik";
import "../CustomPhoneNb/CustomPhoneNumber.css";

const CustomPhoneNumber = ({ label, name, ...rest }) => {
  const { values } = useFormikContext();

  const validatePhoneNumber = (value) => {
    let error;
    if (!value) {
      error = "Mobile Number is required";
    } else if (!/^\d+$/.test(value)) {
      error = "Mobile Number must contain only numbers";
    } else if (value.length !== 10) {
      error = "Mobile Number must be 10 digits";
    }
    return error;
  };

  const isNumeric = (event) => {
    const keyCode = event.which ? event.which : event.keyCode;
    if (keyCode >= 48 && keyCode <= 57) {
      return true;
    }
    return false;
  };

  const handleKeyPress = (event) => {
    if (!isNumeric(event)) {
      event.preventDefault();
    }
  };

  const countryCodes = [
    { value: "+1", label: "+1" },
    { value: "+91", label: "+91 " },
    { value: "+44", label: "+44" },
    { value: "+86", label: "+86" },
  ];

  return (
    <div style={{ width: "85%" }}>
      <label htmlFor={name} className="input-heading">
        {label}
      </label>
      <div style={{ display: "flex", width: "100%" }}>
        <Field
          as="select"
          id={`${name}-country`}
          name={`${name}_country`}
          style={{ marginRight: "-2px" }}
          className="custom-country-field"
        >
          {countryCodes.map(({ value, label }, index) => (
            <option key={value} value={value} disabled={index === 0}>
              {label}
            </option>
          ))}
        </Field>
        <Field
          validate={validatePhoneNumber}
          maxLength="10"
          id={name}
          name={name}
          className="custom-phoneno-field"
          type="tel"
          onKeyPress={handleKeyPress}
          {...rest}
        />
      </div>
      <div style={{ display: "flex" }}>
        <ErrorMessage
          name={`${name}_country`}
          component="div"
          className="inputs-error-msg"
        />
        <ErrorMessage
          name={name}
          component="div"
          className="inputs-error-msg"
        />
      </div>
    </div>
  );
};

export default CustomPhoneNumber