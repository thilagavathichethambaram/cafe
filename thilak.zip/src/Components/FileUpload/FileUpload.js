import React, { useState } from 'react';
import '../FileUpload/FileUpload.css';
import  { ErrorMessage, Field } from "formik";


const FileUploadInput = ({
    label,
    name,
    custPlaceholder,
    inputType,
    showtextPlaceholder,
    textPlaceholder,
    ...rest
}) => {
  const [fileName, setFileName] = useState('');
  const [file, setFile] = useState(null);

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
    setFileName(selectedFile.name);
  };

  const handleUploadClick = () => {
    document.getElementById('file-upload').click();
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <div style={{ position: 'relative' }}>
      <label htmlFor={name} className="input-heading">
            {label}
          </label>
          <div>
        <Field
        id={name}
        name={name}
          type="text"
          placeholder={`${custPlaceholder ? custPlaceholder : "Enter Input"}`}
          {...rest}
          className='custominput-fields'
        //   placeholder="Enter file name or click to upload"
        //   value={fileName || 'No file selected'}
          readOnly
        //   style={{ paddingRight: '80px' }}
        />
        <button
          type="button"
          onClick={handleUploadClick}
          style={{
            position: 'absolute',
            left: '5px',
            top: '70%',
            // bottom:'50%',
            transform: 'translateY(-50%)',
            padding: '1px 1px',
            width:'30%',
            height:'40%',
            color:'whitesmoke',
            fontSize:'10px',
            backgroundColor:'var(--primary-color)',
            border: '1px solid #ced4da',
            borderRadius:'5px',
          }}
        >
         select file...
        </button>
      </div>
      <input
        type="file"
        accept="image/*,.pdf,.doc,.docx"
        onChange={handleFileChange}
        style={{ display: 'none' }}
        id="file-upload"
      />
           </div>   
           <ErrorMessage
          name={name}
          component="div"
          className="inputs-error-msg"
        />
    </div>
  );
};

export default FileUploadInput;