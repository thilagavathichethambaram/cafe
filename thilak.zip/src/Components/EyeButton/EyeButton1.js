import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Modal from "@mui/material/Modal";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import actions from "../../ReduxStore/actions/index";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 900,
  bgcolor: "background.paper",
  border: "2px solid black",
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};

const NestedModal = ({ open, onClose, id }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    if (id) {
      const data = {
        data: {},
        method: "get",
        apiName: `getcompany/${id?.company_id}`,
      };
      dispatch(actions.COMPANYGetById(data));
    }
  }, [dispatch, id]);

  const { CompanyGetById } = useSelector((state) => state?.CompanyGetById);

  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="parent-modal-title"
      aria-describedby="parent-modal-description"
    >
      <Box sx={{ ...style }}>
        <h2 id="parent-modal-title">Branch Details</h2>
        <div
          className="Close_Button"
          onClick={onClose}
          style={{
            position: "absolute",
            top: "10px",
            right: "10px",
            cursor: "pointer",
          }}
        >
          X
        </div>
        <Grid
          container
          className="grid-container"
          md={12}
          lg={12}
          sm={12}
          xs={12}
        >
          <Grid item md={6} lg={6} sm={10} xs={12}>
            <Grid container md={12} lg={12} sm={12} xs={12}>
              <Grid item md={6} lg={6} sm={10} xs={12}>
                <div className="grid-container">
                  <div className="grid-item">Company Name</div>
                  <div className="grid-item">Branch Email</div>
                  <div className="grid-item">Contact Person Name</div>
                  <div className="grid-item">Branch Address</div>
                </div>
              </Grid>
              <Grid item md={6} lg={6} sm={10} xs={12}>
                <div className="grid-item">
                  <span>:&nbsp;</span>
                  {CompanyGetById?.data?.company_name}
                </div>
                <div className="grid-item">
                  <span>:&nbsp;</span>
                  {CompanyGetById?.data?.company_email}
                </div>
                <div className="grid-item">
                  <span>:&nbsp;</span>
                  {CompanyGetById?.data?.contact_person_name}
                </div>
                <div className="grid-item">
                  <span>:&nbsp;</span>
                  {CompanyGetById?.data?.address}
                </div>
              </Grid>
            </Grid>
          </Grid>

          <Grid item md={6} lg={6} sm={10} xs={12}>
            <Grid container md={12} lg={12} sm={12} xs={12}>
              <Grid item md={6} lg={6} sm={10} xs={12}>
                <div className="grid-container">
                  <div className="grid-item">Registration Number</div>
                  <div className="grid-item">Landline Number</div>
                  <div className="grid-item">Contact Person Number</div>
                </div>
              </Grid>
              <Grid item md={6} lg={6} sm={10} xs={12}>
                <div className="grid-item">: 6392712542</div>
                <div className="grid-item">: +91 6342146694</div>
                <div className="grid-item">: +91 9773547391</div>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </Modal>
  );
};

export default NestedModal;
