// import VisibilityIcon from '@mui/icons-material/Visibility';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Modal from '@mui/material/Modal';
// import { styled } from '@mui/system';
import * as React from 'react';
import { useEffect } from 'react';
import { MdOutlineRemoveRedEye } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import actions from "../../ReduxStore/actions/index";
import './EyeButton1.css';
// const EyeButton = styled('button')({
//   background: 'none',
//   border: 'none',
//   cursor: 'pointer',
//   padding: '0',
// });

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 900,
  bgcolor: 'background.paper',
    border: '2px solid red',
  boxShadow: 24,
  pt: 2,
  px: 4,
  pb: 3,
};



export default function NestedModal({open,onClose,id}) {

  
  const dispatch = useDispatch();
  
  useEffect(() => {
    if (id) {
    const data = {
      data: {},
      method: "get",
      apiName: `getEmployeeById/${id?.employee_id}`,
    };
    dispatch(actions.EMPLOYEEGetById(data))
   
  };}
   

,[dispatch, id]);




  const { EmployeeGetById } = useSelector((state) => state?.EmployeeGetById);

  return (
    <div>
     
     <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="parent-modal-title"
      aria-describedby="parent-modal-description"
    >
        
        <Box sx={{ ...style }} >
        <h2 id="parent-modal-title">Employee Details</h2>
        <div className='Close_Button' onClick={onClose} style={{ position: 'absolute', top: '10px', right: '10px', cursor: 'pointer' }}>
            X
          </div>
          <Grid container className="grid-container" md={12} lg={12} sm={12} xs={12}>
          
              <Grid item md={6} lg={6} sm={10} xs={12} >
              <Grid container md={12} lg={12} sm={12} xs={12} >
              <Grid item md={6} lg={6} sm={10} xs={12} >
              <div className="grid-container">
              <div className="grid-item">Employee Name</div>
              <div className="grid-item">Employee Id</div>
              <div className="grid-item">Employee Email</div>
              <div className="grid-item">DOB & doj</div>
              
              </div>
              </Grid>
              <Grid item md={6} lg={6} sm={10} xs={12} >
              <div className="grid-item"> <span>:&nbsp;</span>
                    {EmployeeGetById?.data?.employee_name}</div>
              <div className="grid-item"><span>:&nbsp;</span>
                    {EmployeeGetById?.data?.employee_id}</div>
              <div className="grid-item"><span>:&nbsp;</span>
                    {EmployeeGetById?.data?.employee_email}</div>
              <div className="grid-item"><span>:&nbsp;</span>
                    {EmployeeGetById?.data?.dob}<span>&</span>{EmployeeGetById?.data?.doj} 
                      </div>
              </Grid>
              </Grid>
              </Grid>

              
              <Grid item md={6} lg={6} sm={10} xs={12} >
              <Grid container md={12} lg={12} sm={12} xs={12} >
              <Grid item md={6} lg={6} sm={10} xs={12} >
              <div className="grid-container">
              <div className="grid-item">Designation</div>
              <div className="grid-item">Mobile Number</div>
              <div className="grid-item">Branch</div>
              </div>
              </Grid>
              <Grid item md={6} lg={6} sm={10} xs={12} >
              <div className="grid-item"><span>:&nbsp;</span>
                    {EmployeeGetById?.data?.designation_name}</div>
              <div className="grid-item"><span>:&nbsp;</span>
                    {EmployeeGetById?.data?.mobile_number}</div>
              <div className="grid-item"><span>:&nbsp;</span>
                    {EmployeeGetById?.data?.branch_location}</div>
              </Grid>
              </Grid>
              
              </Grid>
              </Grid>
              

         
        </Box>
      </Modal>
    </div>
  );
}