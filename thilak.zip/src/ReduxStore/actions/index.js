
import { TimeSheetCreateAction } from "../Slices/TimeSheet/TimeSheetCreate";
import { TimeSheetDropdownAction } from "../Slices/TimeSheet/TimeSheetDropdown";
import { TimeSheetGetAllAction } from "../Slices/TimeSheet/TimeSheetGetAll";
import { TimeSheetGetByIdAction } from "../Slices/TimeSheet/TimeSheetGetById";
import { TimeSheetUpdateAction } from "../Slices/TimeSheet/TimeSheetUpdate";
import { BranchCreateAction } from "../Slices/Master/BranchMaster/BranchCreate";
import { BranchDeleteAction } from "../Slices/Master/BranchMaster/BranchDelete";
import { BranchGetAllAction } from "../Slices/Master/BranchMaster/BranchGetAll";
import { BranchGetByIdAction } from "../Slices/Master/BranchMaster/BranchGetById";
import { BranchUpdateAction } from "../Slices/Master/BranchMaster/BranchUpdate";
import { BranchDropdownAction } from "../Slices/Master/BranchMaster/BranchDropDown";
import { CreateCompanyMasterAction } from "../Slices/Master/CompanyMasterSlice/CompanyCreate";
import { CompanyDeleteAction } from "../Slices/Master/CompanyMasterSlice/CompanyDelete";
import { CompanyGetByIdAction } from "../Slices/Master/CompanyMasterSlice/CompanyGetById";
import { CompanyTableGetAllAction } from "../Slices/Master/CompanyMasterSlice/CompanyTableGetAll";
import { CompanyUpdateAction } from "../Slices/Master/CompanyMasterSlice/CompanyUpdate";
import { DesginationDropDownAction } from "../Slices/Master/EmployeeMaster/DesginationDropDown";
import { EmployeeCreateAction } from "../Slices/Master/EmployeeMaster/EmployeeCreate";
import { EmployeeDeleteAction } from "../Slices/Master/EmployeeMaster/EmployeeDelete";
import { EmployeeGetAllAction } from "../Slices/Master/EmployeeMaster/EmployeeGetAll";
import { EmployeeGetByIdAction } from "../Slices/Master/EmployeeMaster/EmployeeGetById";
import { EmployeeUpdateAction } from "../Slices/Master/EmployeeMaster/EmployeeUpdate";
import { EmpBranchDropDownAction } from "../Slices/Master/EmployeeMaster/EmpBranchDropDown";
import { UserMasterBranchDropDownAction } from "../Slices/Master/UserMaster/UserMasterBranchDropDown";
import { UserEmployeeDropDownAction } from "../Slices/Master/UserMaster/UserEmployeeDropDown";
import { UserDropDownAction } from "../Slices/Master/UserMaster/UserDropDown";
import { UserRoleDropDownAction } from "../Slices/Master/RoleMaster/UserRoleDropDown";
import {RoleMasterGetAllAction} from "../Slices/Master/RoleMaster/RoleMastergetAll";
import {RollMasterCreateAction} from "../Slices/Master/RoleMaster/RoleMasterCreate";
import { PayrollCreateAction } from "../Slices/Payroll/StaffDetails/PayrollCreate";
import { PayrollBranchDropDownAction } from "../Slices/Payroll/PayrollBranchDropDown";
import { UserMasterCreateAction } from "../Slices/Master/UserMaster/UserMasterCreate";
import { UserGetAllAction } from "../Slices/Master/UserMaster/UserGetAll";
import { UserGetByIdAction } from "../Slices/Master/UserMaster/UserGetById";
import { UserUpdateAction } from "../Slices/Master/UserMaster/UserUpdate";
import { UserDeleteAction } from "../Slices/Master/UserMaster/UserDelete";


const actions = {

  ...TimeSheetCreateAction,
  ...TimeSheetDropdownAction,
  ...TimeSheetGetAllAction,
  ...TimeSheetGetByIdAction,
  ...TimeSheetUpdateAction,
  ...BranchDeleteAction,
  ...BranchGetAllAction,
  ...BranchGetByIdAction,
  ...BranchUpdateAction,
  ...BranchCreateAction,
  ...BranchDropdownAction,
  ...CreateCompanyMasterAction,
  ...CompanyDeleteAction,
  ...CompanyGetByIdAction,
  ...CompanyTableGetAllAction,
  ...CompanyUpdateAction,
  ...EmpBranchDropDownAction,
  ...DesginationDropDownAction,
  ...EmployeeCreateAction,
  ...EmployeeDeleteAction,
  ...EmployeeGetAllAction,
  ...EmployeeGetByIdAction,
  ...EmployeeUpdateAction,
  ...UserMasterBranchDropDownAction,
  ...UserEmployeeDropDownAction,
  ...UserDropDownAction,
  ...UserRoleDropDownAction,
  ...RoleMasterGetAllAction,
  ...RollMasterCreateAction,
  ...PayrollCreateAction,
  ...PayrollBranchDropDownAction,
  ...UserMasterCreateAction,
  ...UserGetAllAction,
  ...UserGetByIdAction,
  ...UserUpdateAction,
  ...UserDeleteAction
};

export default actions;
