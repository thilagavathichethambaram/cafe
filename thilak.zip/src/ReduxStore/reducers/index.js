import { combineReducers } from "redux";
import { configureStore } from "@reduxjs/toolkit";
import TimeSheetCreateSlice from "../Slices/TimeSheet/TimeSheetCreate";
import TimeSheetDropdownSlice from "../Slices/TimeSheet/TimeSheetDropdown";
import TimeSheetGetAllSlice from "../Slices/TimeSheet/TimeSheetGetAll";
import TimeSheetGetByIdSlice from "../Slices/TimeSheet/TimeSheetGetById";
import TimeSheetUpdateSlice from "../Slices/TimeSheet/TimeSheetUpdate";
import BranchUpdateSlice from "../Slices/Master/BranchMaster/BranchUpdate";
import BranchCreateSlice from "../Slices/Master/BranchMaster/BranchCreate";
import BranchGetByIdSlice from "../Slices/Master/BranchMaster/BranchGetById";
import BranchGetAllSlice from "../Slices/Master/BranchMaster/BranchGetAll";
import BranchDeleteSlice from "../Slices/Master/BranchMaster/BranchDelete";
import EmployeeUpdateSlice from "../Slices/Master/EmployeeMaster/EmployeeUpdate";
import BranchDropdownSlice from "../Slices/Master/BranchMaster/BranchDropDown"
import EmployeeGetByIdSlice from '../Slices/Master/EmployeeMaster/EmployeeGetById'
import EmployeeGetAllSlice from "../Slices/Master/EmployeeMaster/EmployeeGetAll";
import EmployeeDeleteSlice from "../Slices/Master/EmployeeMaster/EmployeeDelete";
import EmployeeCreateSlice from "../Slices/Master/EmployeeMaster/EmployeeCreate";
import EmpBranchDropDownSlice from "../Slices/Master/EmployeeMaster/EmpBranchDropDown";
import DesginationDropDownSlice from "../Slices/Master/EmployeeMaster/DesginationDropDown";
import  CreateCompanyMasterSlice from "../Slices/Master/CompanyMasterSlice/CompanyCreate";
import CompanyDeleteSlice from "../Slices/Master/CompanyMasterSlice/CompanyDelete";
import CompanyGetByIdSlice from "../Slices/Master/CompanyMasterSlice/CompanyGetById";
import CompanyTableGetAllSlice from "../Slices/Master/CompanyMasterSlice/CompanyTableGetAll";
import CompanyUpdateSlice from "../Slices/Master/CompanyMasterSlice/CompanyUpdate";
import UserMasterBranchDropDownSlice from "../Slices/Master/UserMaster/UserMasterBranchDropDown";
import  UserDropDownSlice from "../Slices/Master/UserMaster/UserDropDown";
import UserEmployeeDropDownSlice from "../Slices/Master/UserMaster/UserEmployeeDropDown";
import UserRoleDropDownSlice from "../Slices/Master/RoleMaster/UserRoleDropDown";
// import UserMasterCreateSlice from "../Slices/Master/RoleMaster/RoleMasterCreate";
import  RoleMasterGetAllSlice  from "../Slices/Master/RoleMaster/RoleMastergetAll";
import PayrollCreateSlice from "../Slices/Payroll/StaffDetails/PayrollCreate";
import PayrollBranchDropDownSlice from "../Slices/Payroll/PayrollBranchDropDown";
import UserMasterCreateSlice from "../Slices/Master/UserMaster/UserMasterCreate";
import UserGetAllSlice from "../Slices/Master/UserMaster/UserGetAll";
import UserGetByIdSlice from "../Slices/Master/UserMaster/UserGetById";
import  UserUpdateSlice  from "../Slices/Master/UserMaster/UserUpdate";
import  UserDeleteSlice from "../Slices/Master/UserMaster/UserDelete";






const reducer = combineReducers({
  TimeSheetCreate: TimeSheetCreateSlice,
  TimeSheetDropdown: TimeSheetDropdownSlice,
  TimeSheetGetAll: TimeSheetGetAllSlice,
  TimeSheetGetById: TimeSheetGetByIdSlice,
  TimeSheetUpdate: TimeSheetUpdateSlice,
  BranchUpdate:BranchUpdateSlice,
  BranchCreate:BranchCreateSlice,
  BranchGetById:BranchGetByIdSlice,
  BranchGetAll:BranchGetAllSlice,
  BranchDelete:BranchDeleteSlice,
  EmployeeUpdate:EmployeeUpdateSlice,
  BranchDropdown:BranchDropdownSlice,
  EmployeeGetById:EmployeeGetByIdSlice,
  EmployeeGetAll:EmployeeGetAllSlice,
  EmployeeDelete:EmployeeDeleteSlice,
  EmployeeCreate:EmployeeCreateSlice,
  EmpBranchDropDown:EmpBranchDropDownSlice,
  DesginationDropDown:DesginationDropDownSlice,
  CreateCompanyMaster:CreateCompanyMasterSlice,
  CompanyDelete:CompanyDeleteSlice,
  CompanyGetById:CompanyGetByIdSlice,
  CompanyTableGetAll:CompanyTableGetAllSlice,
  CompanyUpdate:CompanyUpdateSlice,
  UserMasterBranchDropDown:UserMasterBranchDropDownSlice,
  UserDropDown:UserDropDownSlice,
  UserEmployeeDropDown:UserEmployeeDropDownSlice,
  UserRoleDropDown:UserRoleDropDownSlice,
  RoleMasterGetall:RoleMasterGetAllSlice,
  PayrollCreate:PayrollCreateSlice,
  PayrollBranchDropDown:PayrollBranchDropDownSlice,
  UserMasterCreate:UserMasterCreateSlice,
  UserGetAll:UserGetAllSlice,
  UserGetById:UserGetByIdSlice,
  UserUpdate:UserUpdateSlice,
  UserDelete:UserDeleteSlice,
});

const store = configureStore({
  reducer,
});
export default store;
