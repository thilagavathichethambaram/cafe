import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const COMPANYUPDATE = createAsyncThunk(
  "CompanyUpdate/CompanyUpdate",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const CompanyUpdateSlice = createSlice({
  name: "CompanyUpdateSlice",
  initialState: {
    CompanyUpdate: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(COMPANYUPDATE.fulfilled, (state, action) => {
      state.CompanyUpdate = {
        ...state.CompanyUpdate,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYUPDATE.pending, (state, action) => {
      state.CompanyUpdate = {
        ...state.CompanyUpdate,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYUPDATE.rejected, (state, action) => {
      state.CompanyUpdate = {
        ...state.CompanyUpdate,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const CompanyUpdateAction = {
    COMPANYUPDATE,
};

export { CompanyUpdateAction };
export default CompanyUpdateSlice.reducer;