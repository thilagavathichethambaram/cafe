import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const COMPANYTABLEGETALL = createAsyncThunk(
  "CompanyTableGetAll/CompanyTableGetAll",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const CompanyTableGetAllSlice = createSlice({
  name: "CompanyTableGetAllSlice",
  initialState: {
    CompanyTableGetAll: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(COMPANYTABLEGETALL.fulfilled, (state, action) => {
      state.CompanyTableGetAll = {
        ...state.CompanyTableGetAll,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYTABLEGETALL.pending, (state, action) => {
      state.CompanyTableGetAll = {
        ...state.CompanyTableGetAll,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYTABLEGETALL.rejected, (state, action) => {
      state.CompanyTableGetAll = {
        ...state.CompanyTableGetAll,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const CompanyTableGetAllAction = {
    COMPANYTABLEGETALL,
};

export { CompanyTableGetAllAction };
export default CompanyTableGetAllSlice.reducer;