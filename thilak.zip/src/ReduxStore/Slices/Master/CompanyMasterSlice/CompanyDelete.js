import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const COMPANYDELETE = createAsyncThunk(
  "CompanyDelete/CompanyDelete",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const CompanyDeleteSlice = createSlice({
  name: "CompanyDeleteSlice",
  initialState: {
    CompanyDelete: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(COMPANYDELETE.fulfilled, (state, action) => {
      state.CompanyDelete = {
        ...state.CompanyDelete,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYDELETE.pending, (state, action) => {
      state.CompanyDelete = {
        ...state.CompanyDelete,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYDELETE.rejected, (state, action) => {
      state.CompanyDelete = {
        ...state.CompanyDelete,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const CompanyDeleteAction = {
    COMPANYDELETE,
};

export { CompanyDeleteAction };
export default CompanyDeleteSlice.reducer;