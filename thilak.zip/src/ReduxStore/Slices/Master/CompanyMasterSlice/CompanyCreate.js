import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const CREATECOMPANYMASTER = createAsyncThunk(
  "CreateCompanyMaster/CreateCompanyMaster",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const CreateCompanyMasterSlice = createSlice({
  name: "CreateCompanyMasterSlice",
  initialState: {
    CreateCompanyMaster: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(CREATECOMPANYMASTER.fulfilled, (state, action) => {
      state.CreateCompanyMaster = {
        ...state.CreateCompanyMaster,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(CREATECOMPANYMASTER.pending, (state, action) => {
      state.CreateCompanyMaster = {
        ...state.CreateCompanyMaster,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(CREATECOMPANYMASTER.rejected, (state, action) => {
      state.CreateCompanyMaster = {
        ...state.CreateCompanyMaster,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const CreateCompanyMasterAction = {
  CREATECOMPANYMASTER,
};

export { CreateCompanyMasterAction };
export default CreateCompanyMasterSlice.reducer;