import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const COMPANYGetById = createAsyncThunk(
  "CompanyGetById/CompanyGetById",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const CompanyGetByIdSlice = createSlice({
  name: "CompanyGetByIdSlice",
  initialState: {
    CompanyGetById: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(COMPANYGetById.fulfilled, (state, action) => {
      state.CompanyGetById = {
        ...state.CompanyGetById,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYGetById.pending, (state, action) => {
      state.CompanyGetById = {
        ...state.CompanyGetById,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(COMPANYGetById.rejected, (state, action) => {
      state.CompanyGetById = {
        ...state.CompanyGetById,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const CompanyGetByIdAction = {
    COMPANYGetById,
};

export { CompanyGetByIdAction };
export default CompanyGetByIdSlice.reducer;