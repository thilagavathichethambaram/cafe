/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const USERUPDATE = createAsyncThunk(
  "UserUpdate/UserUpdate",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const UserUpdateSlice = createSlice({
  name: "UserUpdateSlice",
  initialState: {
    UserUpdate: {
      ...defaultState.List,
      loading: false,
      error: false,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(USERUPDATE.fulfilled, (state, action) => {
      state.UserUpdate = {
        ...state.UserUpdate,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(USERUPDATE.pending, (state, action) => {
      state.UserUpdate = {
        ...state.UserUpdate,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(USERUPDATE.rejected, (state, action) => {
      state.UserUpdate = {
        ...state.UserUpdate,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const UserUpdateAction = {
  USERUPDATE,
};

export { UserUpdateAction };
export default UserUpdateSlice.reducer;