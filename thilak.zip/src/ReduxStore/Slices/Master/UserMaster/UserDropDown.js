/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const USERDROPDOWN = createAsyncThunk(
  "UserDropDown/UserDropDown",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {

    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const UserDropDownSlice = createSlice({
  name: "UserDropDown",
  initialState: {
    UserDropDown: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(USERDROPDOWN.fulfilled, (state, action) => {
      state.UserDropDown = {
        ...state.UserDropDown,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(USERDROPDOWN.pending, (state, action) => {
      state.UserDropDown = {
        ...state.UserDropDown,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(USERDROPDOWN.rejected, (state, action) => {
      state.UserDropDown = {
        ...state.UserDropDown,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const UserDropDownAction = {
    USERDROPDOWN,
};

export { UserDropDownAction };
export default UserDropDownSlice.reducer;