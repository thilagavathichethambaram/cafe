/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const USERGETALL = createAsyncThunk(
  "UserGetAll/UserGetAll",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const UserGetAllSlice = createSlice({
  name: "UserGetAllSlice",
  initialState: {
    UserGetAll: {
      ...defaultState.List,
      loading: false,
      error: false,
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(USERGETALL.fulfilled, (state, action) => {
      state.UserGetAll = {
        ...state.UserGetAll,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(USERGETALL.pending, (state, action) => {
      state.UserGetAll = {
        ...state.UserGetAll,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(USERGETALL.rejected, (state, action) => {
      state.UserGetAll = {
        ...state.UserGetAll,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const UserGetAllAction = {
  USERGETALL,
};

export { UserGetAllAction };
export default UserGetAllSlice.reducer;