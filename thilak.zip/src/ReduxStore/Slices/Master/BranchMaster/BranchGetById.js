/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const BRANCHGETBYID = createAsyncThunk(
  "BranchGetById/BranchGetById",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const BranchGetByIdSlice = createSlice({
  name: "BranchGetByIdSlice",
  initialState: {
    BranchGetById: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(BRANCHGETBYID.fulfilled, (state, action) => {
      state.BranchGetById = {
        ...state.BranchGetById,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(BRANCHGETBYID.pending, (state, action) => {
      state.BranchGetById = {
        ...state.BranchGetById,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(BRANCHGETBYID.rejected, (state, action) => {
      state.BranchGetById = {
        ...state.BranchGetById,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const BranchGetByIdAction = {
    BRANCHGETBYID,
};

export { BranchGetByIdAction };
export default BranchGetByIdSlice.reducer;
