import { Container, Grid } from "@mui/material";
import React, { useState, useEffect,useRef} from "react";
// import "../Css/timesheet.css";
import { useDispatch, useSelector } from "react-redux";
import CustomDateInput from "../../../Components/CustomDate/CustomDateInput";
import CustomDropdownMui from "../../../Components/CustomDropDown/CustomDropdown";
import CustomInput from "../../../Components/CustomInput/CustomInput";
import CustomPhoneNumber from "../../../Components/CustomPhoneNb/CustomPhoneNumber";

import { Email, Password } from "@mui/icons-material";
import { Form, Formik } from "formik";
import CusTable from "../../../Components/CustomTable/EmpTable";
import * as MASTER from "../../../Components/CustomTable/Empentries";

import Toast from "../../../Components/Toast/Toaste";
import actions from "../../../ReduxStore/actions";
const EmployeeMaster = () => {
  const dispatch = useDispatch();
  const [toastMessage, setToastMessage] = useState("");
  const [backColor, setBackColor] = useState("");
  const [showToast, setShowToast] = useState(false);
  const [changebtn, setchangebtn] = useState(true);
  const formikRef = useRef();
  const { EmployeeDelete } = useSelector((state) => state?.EmployeeDelete);

///////////GetById/////////////
  const { EmployeeGetById } = useSelector((state) => state?.EmployeeGetById);
  console.log(EmployeeGetById, "EmployeeGetById");
const setDefaultFieldValues = (id) => {
  const data = {
    data: {},
    method: "get",
    apiName: `getAllBranches/${id}`,
  };
  dispatch(actions.EMPLOYEEGETBYID(data));
  const { setFieldValue } = formikRef.current;
  if (setFieldValue && EmployeeGetById?.data?.length) {
    setFieldValue("Branch_id", EmployeeGetById.data[0]?.Branch_id);
  
  }
  setchangebtn(false);
};
  /////////////////////
  const OnViewClick = (id) => {
    const data = {
      data: {},
      method: "get",
      apiName: `getEmployeeById/${id?.branch_id}`,
    };
    dispatch(actions.EMPLOYEEGETBYID(data));
    if (EmployeeGetById?.data) {
      console.log("Successfully Deleted!");
      
    } else {
      console.log("failed");
      
    }
    
  };
  
////////////Create
  const handleSubmit = (values, { setSubmitting, resetForm }) => {
    // Handle form submission
    console.log(values);
    if (changebtn === true) {
      const data1 = {
         data: { ...values
        
      },
         method: "post",
       apiName: 'createEmployeeMaster',
      };
    
      dispatch(actions.EMPLOYEECREATE(data1));


      const data = { data: {}, method: "get", apiName: "getAllEmployee" };
      dispatch(actions.EMPLOYEEGETALL(data));
    }

    
    if (changebtn === false) {
      const data2 = {
        data: { ...values },
        method: "put",
        apiName: `updateEmployeeMaster/${EmployeeGetById.data.company_name}`,
      };

      dispatch(actions.COMPANYUPDATE(data2));
      setchangebtn(true);
      
    
    }
   
    resetForm();
    setSubmitting(false);
  }   
  // /////delete
  const handleDelete = (id) => {
   
    const data = {
      data: {},
      method: "DELETE",
      apiName: `deleteEmployee/${id?.employee_id}`,
    };
    dispatch(actions.EMPLOYEEDELETE(data));

//-------------------------------------------------------------------------------------------------

    const data1 = { data: {}, method: "get", apiName: "getEmployeeDetails" };
    dispatch(actions.EMPLOYEEGETALL(data1));
    if (EmployeeDelete?.data) {
      triggerToast("Successfully Deleted!");
      setBackColor("green")
    } else {
      triggerToast("failed");
      setBackColor("red")
    }
  };
  
  const triggerToast = (message) => {
    console.log(message, "toast work successfully");
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 3000); // Toast will disappear after 3 seconds
  };
 
   const {EmployeeGetAll}= useSelector(
    (state)=> state?.EmployeeGetAll
   )
  useEffect(() => {
    const data1 = { data: {}, method: "get", apiName: "getAllEmployee" };
    dispatch(actions.EMPLOYEEGETALL(data1));
  }, [dispatch]);

  const [rowTableData, setRowTableData] = useState([]);

  useEffect(() => {
    if (EmployeeGetAll?.data) {
      const tempArr1 = EmployeeGetAll.data.map((data, index) => ({
        Sno: index + 1,
       
       
        employee_name: data.employee_name,
        // employee_unique_id: data.employee_unique_id,
        employee_id: data.employee_id,
        designation_id: data.designation_name,
         employee_email: data.employee_email,
         branch_id: data.branch_location
        
      }));
      setRowTableData(tempArr1);
    }
  }, [EmployeeGetAll]);
////////////////////////////////////////DropDown
const { BranchDropDown } = useSelector(
  (state) => state?.BranchDropDown
);
// console.log(BranchDropDown, "BranchDropDownllllll");

useEffect(() => {
  const data = { data: {}, method: "get", apiName: "branchDropDown" };
  dispatch(actions.BRANCHDROPDOWN(data));
}, [dispatch]);

const [BranchDrop, setBranchDrop] = useState([]);
useEffect(() => {
  const tempArr = [];
  BranchDropDown?.data?.map((values, index) =>
    tempArr.push({
      value: values?.branch_id,
      label: values?.branch_location,
    })
  );
  setBranchDrop(tempArr);
}, [BranchDropDown]);
/////////////////////////DesginationDropDown
const { DesginationDropDown } = useSelector(
  (state) => state?.DesginationDropDown
);
// console.log(BranchDropDown, "BranchDropDownllllll");

useEffect(() => {
  const data = { data: {}, method: "get", apiName: "designationDropDown" };
  dispatch(actions.DESGINATIONDROPDOWN(data));
}, [dispatch]);

const [DesginationDrop, setDesginationDrop] = useState([]);
useEffect(() => {
  const tempArr = [];
  DesginationDropDown?.data?.map((values, index) =>
    tempArr.push({
      value: values?.designation_id,
      label: values?.designation_name,
    })
  );
  setDesginationDrop(tempArr);
}, [DesginationDropDown]);

  return (
    <div style={{height: "100%", width: "100%" }}>
      <Grid
        container
        md={12}
        style={{
          height: "100%",
        }}
      >
        {/* input field */}
        <Grid item md={12} sx={{ marginTop: "20px" }}>
        <Formik
            initialValues={{
              branch_id:"",
      designation_id:"",
      employee_unique_id:"",
      employee_name:"",
      employee_email:"",
      employee_password:"",
      dob:"",
      doj:"",
      mobile_number:"",
      adhaar_number:""
        
            }}
            // style={{ height: "100%" }}
             onSubmit={handleSubmit}
          >
            {({ isSubmitting, resetForm, setFieldValue }) => (
              <Form style={{ height: "100%" }} className="fomik-form">
                <Container
                  style={{
                    width: "98%",
                    backgroundColor: "white",
                    padding: "0px 40px 10px",
                    height: "100%",
                    borderRadius: "15px",
                  }}
                >
                  {/* heading Row */}
                  <Grid container sx={{ height: "100%" }}>
                    {/* First Row */}
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDropdownMui
                        label="Branch"
                        name="branch_id"
                        custPlaceholder="Select Branch"
                          setFieldValue={setFieldValue}
                        options={BranchDrop}
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Employee Name"
                        name="employee_name"
                        inputType={"text"}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Employee Id"
                        name="employee_unique_id"
                        inputType={"text"}
                        custPlaceholder=" "
                      />
                    </Grid>

                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomDropdownMui
                        label="Designation"
                        name="designation_id"
                        custPlaceholder="Select Designation"
                          setFieldValue={setFieldValue}
                        options={DesginationDrop}
                        />
                        
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput
                        label="Email"
                        name="employee_email"
                       inputType={Email}
                       custPlaceholder=" " 
                        
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomInput label="Password" name="employee_password" 
                      inputType={Password}
                      custPlaceholder=" "/>
                    </Grid>
                    
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "Start",
                        marginTop: "5px",
                        // height: "30%",
                      }}
                    >
                      <CustomPhoneNumber
                        label="Mobile Number"
                        name="mobile_number"
                      
                        //   selectEmployeeIdfn={selectEmployeeIdfn}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDateInput
                        label="DOJ"
                        name="doj"
                        
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid
                      item
                      xs={4}
                      sx={{
                        display: "flex",
                        justifyContent: "end",
                        marginTop: "5px",
                      }}
                    >
                      <CustomDateInput label="DOB" name="dob" custPlaceholder=" " />
                      </Grid> 
                        
                        
                <Grid item xs={4}  sx={{
                        display: "flex",
                        justifyContent: "start",
                        marginTop: "5px",
                      }} >
                   
                      <CustomInput
                        label="Adhaar Number"
                        name="adhaar_number"
                        inputType={"number"}
                        custPlaceholder=" "
                      />
                    </Grid>
                    <Grid>
                      
                    </Grid>
                    <Grid item      xs={4}>           
                      </Grid>

                    <Grid item xs={4}
                     
                     sx={{
                       display: "flex",
                       justifyContent: "end",
                       alignItems: "end",
                       marginTop: "15px",
                     }}
                   >
                     {changebtn ? (
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="expense-submit-btn"
                        >
                          Submit
                        </button>
                      ) : (
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="expense-submit-btn"
                        >
                          Update
                        </button>
                      )}

                     <button
                       type="button"
                       onClick={() => {}}
                       className="expense-cancel-btn"
                       style={{ border: "1px solid var(--primary-color)" }}
                     >
                       Cancel
                     </button></Grid>
                    <Grid item xs={4}></Grid>
                    <Grid>
                      
                    </Grid>
                  </Grid>
                </Container>
              </Form>
            )}
          </Formik>
        </Grid>
        <Grid item md={12} sx={{}}>
          <Container
            style={{
              width: "98%",
              padding: "0px",
              marginTop: "15px",
              marginBottom: "15px",
              background: "white",
              borderRadius: "10px",
              //   boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            }}
          >
            <Grid container>
              <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.EmployeeMasterTableHeaders}
                  Tabledata={rowTableData}
                  TableTittle="Overview"
                  // showEmpDetails={true}
                  showAction={true}
                  showSearch={true}
                  // onViewClick={handleViewClick}
                  OnViewClick={(id) => OnViewClick(id)}
                  setDefaultFieldValues={(id)=>setDefaultFieldValues(id)}
                  handleDelete={(id)=>handleDelete(id)}
                />
                {/* {modalOpen && <ModelOpen open={open} handleClose={handleClose} handleOpen={handleOpen}/>} */}
              </Grid>
            </Grid>
          </Container>
        </Grid>
      </Grid>
      {showToast && (
          <Toast message={toastMessage} backColor={backColor}/>
        )} 
    </div>
  );
};

export default EmployeeMaster;
