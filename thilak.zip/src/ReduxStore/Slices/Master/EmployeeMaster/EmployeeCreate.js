/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const EMPLOYEECREATE = createAsyncThunk(
  "EmployeeCreate/EmployeeCreate",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const EmployeeCreateSlice = createSlice({
  name: "EmployeeCreateSlice",
  initialState: {
    EmployeeCreate: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(EMPLOYEECREATE.fulfilled, (state, action) => {
      state.EmployeeCreate = {
        ...state.EmployeeCreate,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(EMPLOYEECREATE.pending, (state, action) => {
      state.EmployeeCreate = {
        ...state.EmployeeCreate,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(EMPLOYEECREATE.rejected, (state, action) => {
      state.EmployeeCreate = {
        ...state.EmployeeCreate,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const EmployeeCreateAction = {
    EMPLOYEECREATE,
};

export { EmployeeCreateAction };
export default EmployeeCreateSlice.reducer;
