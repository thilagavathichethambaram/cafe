/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const EMPLOYEEGetById = createAsyncThunk(
  "EmployeeGetById/EmployeeGetById",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const EmployeeGetByIdSlice = createSlice({
  name: "EmployeeGetByIdSlice",
  initialState: {
    EmployeeGetById: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(EMPLOYEEGetById.fulfilled, (state, action) => {
      state.EmployeeGetById = {
        ...state.EmployeeGetById,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(EMPLOYEEGetById.pending, (state, action) => {
      state.EmployeeGetById = {
        ...state.EmployeeGetById,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(EMPLOYEEGetById.rejected, (state, action) => {
      state.EmployeeGetById = {
        ...state.EmployeeGetById,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const EmployeeGetByIdAction = {
    EMPLOYEEGetById,
};

export { EmployeeGetByIdAction };
export default EmployeeGetByIdSlice.reducer;
