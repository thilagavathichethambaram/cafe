/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const DESGINATIONDROPDOWN = createAsyncThunk(
  "DesginationDropDown/DesginationDropDown",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {

    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const DesginationDropDownSlice = createSlice({
  name: "DesginationDropDown",
  initialState: {
    DesginationDropDown: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(DESGINATIONDROPDOWN.fulfilled, (state, action) => {
      state.DesginationDropDown = {
        ...state.DesginationDropDown,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(DESGINATIONDROPDOWN.pending, (state, action) => {
      state.DesginationDropDown = {
        ...state.DesginationDropDown,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase(DESGINATIONDROPDOWN.rejected, (state, action) => {
      state.DesginationDropDown = {
        ...state.DesginationDropDown,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
});

const DesginationDropDownAction = {
    DESGINATIONDROPDOWN,
};

export { DesginationDropDownAction };
export default DesginationDropDownSlice.reducer;