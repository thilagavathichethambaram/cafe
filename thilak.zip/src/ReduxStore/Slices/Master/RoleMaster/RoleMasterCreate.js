/* eslint-disable no-sequences */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { defaultReject, defaultState } from "../../../../constants";
import { fetchData } from "../../../helpers";

const ROLLMASTERCREATE = createAsyncThunk(
  "RollMasterCreate/RollMasterCreate",
  // eslint-disable-next-line default-param-last
  async (
    // eslint-disable-next-line default-param-last
    payload = {},
    { rejectWithValue }
  ) => {
    try {
      const data = await fetchData(
        payload?.data,
        payload?.method,
        payload?.apiName
      );
      return {
        ...defaultState.List,
        message: data?.data.Message,
        data: data?.data?.data,
      };
    } catch (error) {
      return rejectWithValue({
        ...defaultReject.List,
        message: error.message,
      });
    }
  }
);

const RollMasterCreateSlice = createSlice({
  name: "RollMasterCreateSlice",
  initialState: {
    UserMasterCreate: {
      ...defaultState.List,
      loading: false, 
      error: false, 
    },
  },
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase( ROLLMASTERCREATE.fulfilled, (state, action) => {
      state.UserMasterCreate = {
        ...state.UserMasterCreate,
        loading: false,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase( ROLLMASTERCREATE.pending, (state, action) => {
      state.RollMasterCreate = {
        ...state.RollMasterCreate,
        loading: true,
        error: false,
        ...action.payload,
      };
    });
    builder.addCase( ROLLMASTERCREATE.rejected, (state, action) => {
      state.RollMasterCreate = {
        ...state.RollMasterCreate,
        loading: false,
        error: true,
        ...action.payload,
      };
    });
  },
}); 

const RollMasterCreateAction = {
    ROLLMASTERCREATE,
};

export { RollMasterCreateAction };
export default RollMasterCreateSlice.reducer;
